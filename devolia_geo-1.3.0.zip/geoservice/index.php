<?php
	header('Location: www/');
?>