#!/bin/sh
rid=21
if [ "$1" == "" ]
then
	echo "Missing parm: MySQL root password"
	echo "Usage: ./import.sh my_password"
	exit 1
else
	mysqlp=$1
fi
echo "==============================="
echo "1/11 Getting data from GeoNames"
echo "==============================="
wget -q http://download.geonames.org/export/dump/allCountries.zip
wget -q http://download.geonames.org/export/dump/alternateNames.zip
wget -q http://download.geonames.org/export/dump/admin1Codes.txt
wget -q http://download.geonames.org/export/dump/admin1CodesASCII.txt
wget -q http://download.geonames.org/export/dump/featureCodes_en.txt
wget -q http://download.geonames.org/export/dump/timeZones.txt
wget -q http://download.geonames.org/export/dump/countryInfo.txt
echo "==================="
echo "2/11 Unzipping data"
echo "==================="
unzip -qq allCountries.zip
unzip -qq alternateNames.zip
echo "======================="
echo "3/11 Concatenating data"
echo "======================="
cat countryInfo.txt | grep -v "^#" >countryInfo-n.txt
echo "=================================="
echo "4/11 Importing data 1/2 into MySQL"
echo "=================================="
echo "(we know - this is LONG)"
mysql -uroot -p"$mysqlp" <import.sql
echo "========================"
echo "5/11 Removing temp files"
echo "========================"
rm -rf *.zip
rm -rf *.txt
echo "==============================="
echo "6/11 GeoNames installation done"
echo "==============================="
echo "=============================="
echo "7/11 Getting data from MaxMind"
echo "=============================="
wget -q http://geolite.maxmind.com/download/geoip/database/GeoLiteCity_CSV/GeoLiteCity_20101201.zip
unzip -qq GeoLiteCity_20101201.zip
echo "=================================="
echo "8/11 Importing data 2/2 into MySQL"
echo "=================================="
echo "(this is also long...)"
mysql -uroot -p"$mysqlp" <import2.sql
echo "========================"
echo "9/11 Removing temp files"
echo "========================"
rm -rf *.zip
rm -rf GeoLiteCity_20101201/
echo "==============================="
echo "10/11 MaxMind installation done"
echo "==============================="
wget -q http://devolia.org/postinstall.php?pid=3\&rid="$rid" -O ./install.txt
echo "==================================="
echo "11/11 Devolia Geo installation done"
echo "==================================="
echo "Read the manual on http://devolia.org/wiki/Devolia_Geo"