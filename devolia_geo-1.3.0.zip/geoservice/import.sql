--
-- Database creation
--

DROP DATABASE IF EXISTS `devolia_geo`;
CREATE DATABASE `devolia_geo`;
ALTER DATABASE `devolia_geo` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `devolia_geo`;

--
-- Table structure for table `admin1Codes`
--

DROP TABLE IF EXISTS `admin1Codes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `admin1Codes` (
  `code` char(10) default NULL,
  `name` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `admin1CodesAscii`
--

DROP TABLE IF EXISTS `admin1CodesAscii`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `admin1CodesAscii` (
  `code` char(10) default NULL,
  `name` text,
  `nameAscii` text,
  `geonameid` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `alternatename`
--

DROP TABLE IF EXISTS `alternatename`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `alternatename` (
  `alternatenameId` int(11) NOT NULL,
  `geonameid` int(11) default NULL,
  `isoLanguage` varchar(7) default NULL,
  `alternateName` varchar(200) default NULL,
  `isPreferredName` tinyint(1) default NULL,
  `isShortName` tinyint(1) default NULL,
  PRIMARY KEY  (`alternatenameId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `continentCodes`
--

DROP TABLE IF EXISTS `continentCodes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `continentCodes` (
  `code` char(2) default NULL,
  `name` varchar(20) default NULL,
  `geonameid` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `countryInfo`
--

DROP TABLE IF EXISTS `countryInfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `countryInfo` (
  `iso_alpha2` char(2) default NULL,
  `iso_alpha3` char(3) default NULL,
  `iso_numeric` int(11) default NULL,
  `fips_code` varchar(3) default NULL,
  `name` varchar(200) default NULL,
  `capital` varchar(200) default NULL,
  `areainsqkm` bigint(20) default NULL,
  `population` int(11) default NULL,
  `continent` char(2) default NULL,
  `tld` varchar(4) default NULL,
  `currency_code` char(3) default NULL,
  `currency_name` varchar(32) default NULL,
  `phone` varchar(16) default NULL,
  `postal_code_format` varchar(64) default NULL,
  `postal_code_regex` varchar(256) default NULL,
  `languages` varchar(200) default NULL,
  `geonameId` int(11) default NULL,
  `neighbours` varchar(64) default NULL,
  `equivalent_fips_code` varchar(3) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `featureCodes`
--

DROP TABLE IF EXISTS `featureCodes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `featureCodes` (
  `code` char(7) default NULL,
  `name` varchar(200) default NULL,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `geoname`
--

DROP TABLE IF EXISTS `geoname`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `geoname` (
  `geonameid` int(11) NOT NULL,
  `name` varchar(200) default NULL,
  `asciiname` varchar(200) default NULL,
  `alternatenames` varchar(4000) default NULL,
  `latitude` decimal(10,7) default NULL,
  `longitude` decimal(10,7) default NULL,
  `fclass` char(1) default NULL,
  `fcode` varchar(10) default NULL,
  `country` varchar(2) default NULL,
  `cc2` varchar(60) default NULL,
  `admin1` varchar(20) default NULL,
  `admin2` varchar(80) default NULL,
  `admin3` varchar(20) default NULL,
  `admin4` varchar(20) default NULL,
  `population` int(11) default NULL,
  `elevation` int(11) default NULL,
  `gtopo30` int(11) default NULL,
  `timezone` varchar(40) default NULL,
  `moddate` date default NULL,
  PRIMARY KEY  (`geonameid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `geonames_admin2codes`
--

DROP TABLE IF EXISTS `geonames_admin2codes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `geonames_admin2codes` (
  `code` char(10) default NULL,
  `name_local` text,
  `name` text NOT NULL,
  `geonameid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `iso_languagecodes`
--

DROP TABLE IF EXISTS `iso_languagecodes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `iso_languagecodes` (
  `iso_639_3` char(4) default NULL,
  `iso_639_2` varchar(50) default NULL,
  `iso_639_1` varchar(50) default NULL,
  `language_name` varchar(200) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `timeZones`
--

DROP TABLE IF EXISTS `timeZones`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timeZones` (
  `timeZoneId` varchar(200) default NULL,
  `GMT_offset` decimal(3,1) default NULL,
  `DST_offset` decimal(3,1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Chargement des donn�es
--

LOAD DATA LOCAL INFILE 'allCountries.txt' INTO TABLE geoname (geonameid,name,asciiname,alternatenames,latitude,longitude,fclass,fcode,country,cc2, admin1,admin2,admin3,admin4,population,elevation,gtopo30,timezone,moddate);
LOAD DATA LOCAL INFILE 'alternateNames.txt' INTO TABLE alternatename (alternatenameid,geonameid,isoLanguage,alternateName,isPreferredName,isShortName);
LOAD DATA LOCAL INFILE 'iso-languagecodes.txt' INTO TABLE iso_languagecodes (iso_639_3, iso_639_2, iso_639_1, language_name);
LOAD DATA LOCAL INFILE 'admin1Codes.txt' INTO TABLE admin1Codes (code, name);
LOAD DATA LOCAL INFILE 'admin1CodesASCII.txt' INTO TABLE admin1CodesAscii (code, name, nameAscii, geonameid);
LOAD DATA LOCAL INFILE 'featureCodes_en.txt' INTO TABLE featureCodes (code, name, description);
LOAD DATA LOCAL INFILE 'timeZones.txt' INTO TABLE timeZones IGNORE 1 LINES (timeZoneId, GMT_offset, DST_offset);
LOAD DATA LOCAL INFILE 'countryInfo-n.txt' INTO TABLE countryInfo IGNORE 1 LINES (iso_alpha2,iso_alpha3,iso_numeric,fips_code,name,capital,areaInSqKm,population,continent,tld,currency_code,currency_name,phone,postal_code_format,postal_code_regex,languages,geonameId,neighbours,equivalent_fips_code);
LOAD DATA LOCAL INFILE 'continentCodes.txt' INTO TABLE continentCodes FIELDS TERMINATED BY ',' (code, name, geonameId);

--
-- Cr�ation des index
--

ALTER TABLE `geoname` ADD INDEX (`latitude`);
ALTER TABLE `geoname` ADD INDEX (`longitude`);
ALTER TABLE `geoname` ADD INDEX (`fclass`);
ALTER TABLE `geoname` ADD INDEX (`population`);

--
-- Cr�ation de l'utilisateur
--

CREATE USER 'devolia_geo'@'localhost' IDENTIFIED BY 'devolia_geo.2010';
GRANT USAGE ON * . * TO 'devolia_geo'@'localhost' IDENTIFIED BY 'devolia_geo.2010' WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0 ;
GRANT ALL PRIVILEGES ON `devolia_geo` . * TO 'devolia_geo'@'localhost';