/**
 * Devolia Geo GUI Javascript
 * @requires jQuery
 * @version 2010.12.08
 */

/**
 * Send a request on the first field
 */
function process(){
	$('#button').css('display','none');
	$('#img').css('display','block')
	$('#closest_city').html('');
	$('#closest_city_weather').html('');
	$('#google_map').html('');
	
	var url ="geoservice-rpc.php";
	url+='?action=get_closest_city';
	url+='&lat='+encodeURI($('#lat').val());
	url+='&long='+encodeURI($('#long').val());
	url+='&mode=json';
	
	$.ajax({
		url: url,
		type: 'get',
		success: function(transport){
			json=eval(transport);
			if(json.error!=undefined){ alert('Error : '+json.error); }
			$('#closest_city').html(json.city+' ('+json.country+') - process time : '+json.exec_time);
			$('#google_map').html('<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&amp;source=s_q&amp;hl=fr&amp;geocode=&amp;ll='+$('#lat').val()+','+$('#long').val()+'&amp;t=h&amp;z=7&amp;output=embed"></iframe>');
		}
	});
	
	url ="geoservice-rpc.php";
	url+='?action=get_closest_city_weather';
	url+='&lat='+encodeURI($('#lat').val());
	url+='&long='+encodeURI($('#long').val());
	url+='&mode=json';
	
	$.ajax({
		url: url,
		type: 'get',
		success: function(transport){
			json=eval(transport);
			if(json.error!=undefined){ alert('Error : '+json.error); }
			$('#closest_city_weather').html(json.city+' ('+json.country+') - process time : '+json.exec_time+' - weather.com ID : '+json.weather_com_id);
			$('#img').css('display','none');		
			$('#button').css('display','block');
		}
	});
}

/**
 * Send a request on the second field
 */
function process2(){
	$('#button2').css('display','none');
	$('#img2').css('display','block');
	$('#closest_city2').html('');
	$('#closest_city_weather2').html('');
	
	var url ="geoservice-rpc.php";
	url+='?action=get_city_from_ip';
	url+='&ip='+encodeURI($('#ip').val());
	url+='&mode=json';
	
	$.ajax({
		url: url,
		type: 'get',
		success: function(transport){
			json=eval(transport);
			if(json.error!=undefined){ alert('Error : '+json.error); }
			$('#closest_city2').html(json.city+' ('+json.country+') - process time : '+json.exec_time);
			$('#img2').css('display','none');		
			$('#button2').css('display','block');
			$('#google_map2').html('<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&amp;source=s_q&amp;hl=fr&amp;geocode=&amp;ll='+json.latitude+','+json.longitude+'&amp;t=h&amp;z=7&amp;output=embed"></iframe>');
		}
	});
	
	url ="geoservice-rpc.php";
	url+='?action=get_city_from_ip_weather';
	url+='&ip='+encodeURI($('#ip').val());
	url+='&mode=json';
	
	$.ajax({
		url: url,
		type: 'get',
		success: function(transport){
			json=eval(transport);
			if(json.error!=undefined){ alert('Error : '+json.error); }
			$('#closest_city_weather2').html(json.city+' ('+json.country+') - process time : '+json.exec_time+' - weather.com ID : '+json.weather_com_id);
		}
	});
}