<?php
	/**
	 *	config file
	 *	@package geoservice
	 *	@version 2010.06.04
	 */
	define('GEOSERVICE_DB_NAME', 'devolia_geo');
	define('GEOSERVICE_DB_USER', 'devolia_geo');
	define('GEOSERVICE_DB_PASSWORD', 'devolia_geo.2010');
	define('GEOSERVICE_DB_HOST', 'localhost');
	define('GEOSERVICE_DB_CHARSET', 'utf8');
	define('GEOSERVICE_DB_COLLATE', '');
	define('GEOSERVICE_VERSION', '1.3.0');
?>