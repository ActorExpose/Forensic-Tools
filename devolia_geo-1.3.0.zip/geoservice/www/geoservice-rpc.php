<?php
	/**
	 *	The geoservice Remote Procedure Call class
	 *	@package geoservice
	 *	@version 2010.12.08
	 */
	 
	error_reporting(E_ALL);
	ini_set('display_errors','On'); 
	require_once('geoservice-lib/core.incl.php');
	
	if(!db_connect()){
	if($_REQUEST['mode']=='json'){
			header("Content-Type: text/x-json; charset=utf-8");
			print(json_encode(array('error'=>'mysql_error')));
		}
		elseif($_REQUEST['mode']=='xml'){
			header("Content-Type: text/xml; charset=utf-8");
			$xml='<?xml version="1.0" encoding="utf-8"?>'."\r\n";
			$xml.='<data>';
			$xml.='<error>mysql_error</error>';
			$xml.='</data>';
			print($xml);
		}
		exit();
	}
	
	if(isset($_REQUEST['mode'])){ if($_REQUEST['mode']==''){ $_REQUEST['mode']='xml'; }	}else{ $_REQUEST['mode']='xml'; }
	
	// Force refresh every single time
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");

	if(isset($_REQUEST['action'])){
		switch($_REQUEST['action']){
		
			case 'get_closest_city':
				get_closest_city('');
				break;
				
			case 'get_closest_city_weather':
				get_closest_city('weather');
				break;
				
			case 'get_city_from_ip':
				get_city_from_ip('');
				break;
				
			case 'get_city_from_ip_weather':
				get_city_from_ip('weather');
				break;
				
			default:
				no_action();
				break;
		}
	}
	else{ no_action(); }
	
	function no_action(){
		if($_REQUEST['mode']=='json'){
			header("Content-Type: text/x-json; charset=utf-8");
			print(json_encode(array('error'=>'no_action')));
		}
		elseif($_REQUEST['mode']=='xml'){
			header("Content-Type: text/xml; charset=utf-8");
			$xml='<?xml version="1.0" encoding="utf-8"?>'."\r\n";
			$xml.='<data>';
			$xml.='<error>no_action</error>';
			$xml.='</data>';
			print($xml);
		}
	}
	
	function get_city_from_ip($mode){
		$time_start = microtime(true);
		if(isset($_REQUEST['ip'])){ $ip=$_REQUEST['ip']; }else{ $ip=$_SERVER['REMOTE_ADDR']; }
		$split_ip=explode('.',$ip);
		$mm_num=$split_ip[0]*16777216+$split_ip[1]*65536+$split_ip[2]*256+$split_ip[3];
		$sel_req="SELECT `locId` from `blocks` WHERE `startIpNum`<='".$mm_num."' AND `endIpNum`>='".$mm_num."';";
		$recordset=mysql_query($sel_req);
		$resultat=mysql_fetch_array($recordset);
		if($resultat['locId']!=''){
			$sel_req_2="SELECT * FROM `location` WHERE `locId`='".$resultat['locId']."';";	
			$recordset_2=mysql_query($sel_req_2);
			$resultat_2=mysql_fetch_array($recordset_2);
			if($resultat_2['country']!=''){
				$sel_req_3="SELECT `name`, `capital` FROM `countryInfo` WHERE `iso_alpha2`='".$resultat_2['country']."';";	
				$recordset_3=mysql_query($sel_req_3);
				$resultat_3=mysql_fetch_array($recordset_3);
				
				if($resultat_2['city']=='' && $resultat_2['latitude']!='' && $resultat_2['longitude']!=''){
					// No city but coordinates
					$geo2=new geoservice();
					$geo2->lat=$resultat_2['latitude'];
					$geo2->long=$resultat_2['longitude'];
					$city2=$geo2->get_closest_city('');
					$resultat_2['city']=$city2['city'];
				}
				
				$city=array();
				$city['city']=$resultat_2['city'];
				$city['country']=$resultat_3['name'];
				$city['latitude']=$resultat_2['latitude'];
				$city['longitude']=$resultat_2['longitude'];
				
				if($mode=='weather'){
					$geo=new geoservice();
					$geo->lat=$resultat_2['latitude'];
					$geo->long=$resultat_2['longitude'];
					$city=$geo->get_closest_city('weather');
					$time_end = microtime(true);
				}
				else{
					$time_end = microtime(true);
				}
				
				$city['exec_time']=number_format(($time_end - $time_start),2,'.','').' seconds';
				if($_REQUEST['mode']=='json'){
					header("Content-Type: text/x-json; charset=utf-8");
					print(json_encode($city));
				}
				elseif($_REQUEST['mode']=='xml'){
					header("Content-Type: text/xml; charset=utf-8");
					$xml='<?xml version="1.0" encoding="utf-8"?>'."\r\n";
					$xml.='<data>'."\r\n";
					$xml.="\t".'<city>'.$city['city'].'</city>'."\r\n";
					$xml.="\t".'<country>'.$city['country'].'</country>'."\r\n";
					if(isset($city['latitude'])){ $xml.="\t".'<latitude>'.$city['latitude'].'</latitude>'."\r\n"; }
					if(isset($city['longitude'])){ $xml.="\t".'<longitude>'.$city['longitude'].'</longitude>'."\r\n"; }
					$xml.="\t".'<exec_time>'.$city['exec_time'].'</exec_time>'."\r\n";
					if(isset($city['weather_com_id'])){ $xml.="\t".'<weather_com_id>'.$city['weather_com_id'].'</weather_com_id>'."\r\n"; }
					$xml.='</data>';
					print($xml);
				}
				
			}
		}
	}

	/**
	 *	Get the closest city data from current position
	 *	@version 2010.02.20
	 */
	function get_closest_city($mode){
		$time_start = microtime(true);
		$geo=new geoservice();
		if($_REQUEST['lat']!=''){ $geo->lat=$_REQUEST['lat']; }
		if($_REQUEST['long']!=''){ $geo->long=$_REQUEST['long']; }
		$city=$geo->get_closest_city($mode);
		$time_end = microtime(true);
		$city['exec_time']=number_format(($time_end - $time_start),2,'.','').' seconds';
		if($_REQUEST['mode']=='json'){
			header("Content-Type: text/x-json; charset=utf-8");
			print(json_encode($city));
		}
		elseif($_REQUEST['mode']=='xml'){
			header("Content-Type: text/xml; charset=utf-8");
			$xml='<?xml version="1.0" encoding="utf-8"?>'."\r\n";
			$xml.='<data>'."\r\n";
			$xml.="\t".'<city>'.$city['city'].'</city>'."\r\n";
			$xml.="\t".'<country>'.$city['country'].'</country>'."\r\n";
			$xml.="\t".'<exec_time>'.$city['exec_time'].'</exec_time>'."\r\n";
			if(isset($city['weather_com_id'])){ $xml.="\t".'<weather_com_id>'.$city['weather_com_id'].'</weather_com_id>'."\r\n"; }
			$xml.='</data>';
			print($xml);
		}
	}
	
	function return_moder($return){
		if($_REQUEST['mode']=='json'){
			header("Content-Type: text/x-json; charset=utf-8");
			$return=json_encode($return);	
		}
		elseif($_REQUEST['mode']=='xml'){
			header("Content-Type: text/xml; charset=utf-8");
			$return=xmlrpc_encode($return);	
		}
		print($return);
	}
?>