<?php
	/**
	 *	The geoservice Remote Procedure Call class
	 *	@package geoservice
	 */
	 
	class geoservice{
		public $max_loops=10;
		public $debug=false;
		public $lat=48.859685;
		public $long=2.348841;

		
		function __construct(){
			
		}
		
		/**
		 *	Does Weather.com know the city
		 *	@version 2010.02.20
		 */
		function known_weather_city($city, $country){
			$url='http://xoap.weather.com/search/search?where='.urlencode($city.', '.$country);
			$data=file_get_contents($url);
			$loc_xml=new SimpleXMLElement($data);
			
			$return=array();
			
			if(!empty($loc_xml->loc)){
				$return['success']=true;
				$return['weather_com_id']=(string)$loc_xml->loc[0]['id'];
				return($return);
			}
			else{
				$return['success']=false;
				return($return);
			}
		}
		
		function get_closest_city($mode){
			$lat_long_ratio=3.5;
			$lat_delta=0.02;
			$long_delta=$lat_delta*$lat_long_ratio;
			
			$city_found=false;
			$delta_k=1;
			
			while($city_found==false){
				if($delta_k>$this->max_loops){
					//
					$ville=array();
					$ville['city']='Paris';
					$ville['country']='France';
					$ville['weather_com_id']='FRXX0076';
					return($ville);
					exit();
				}
				//if($this->debug){ print('Checking for cities around, round #'.$delta_k.'<br />'); }
				$lat_delta=$delta_k*$lat_delta;
				$long_delta=$lat_delta*$lat_long_ratio;
				
				$sel_req="	SELECT * FROM 
						`geoname` 
					WHERE 
						`fclass`='P' 
					AND 
						`latitude`<'".($this->lat+$lat_delta)."'
					AND 
						`latitude`>'".($this->lat-$lat_delta)."'
					AND 
						`longitude`<'".($this->long+$long_delta)."'
					AND 
						`longitude`>'".($this->long-$long_delta)."'";
				if($mode=='weather'){
					//if($debug){ print('We want a city known by weather.com...<br/>'); }
					$sel_req.=" AND `population`>50000 ";
				}
				else{
					$sel_req.=" AND `population`>0 ";
				}
				$sel_req.="ORDER BY (ABS(`latitude`-".$this->lat.") + ".$lat_long_ratio."*ABS(`longitude`-".$this->long.")) ASC ";
				if($mode==''){
					$sel_req.="LIMIT 1;";
					//print($sel_req);
					$recordset=mysql_query($sel_req);
					$resultat=mysql_fetch_array($recordset);
					if($resultat['name']!=''){
						$city_found=true;
						$sel_req_2="SELECT `name` FROM countryInfo WHERE `iso_alpha2`='".$resultat['country']."';";
						$recordset_2=mysql_query($sel_req_2);
						$resultat_2=mysql_fetch_array($recordset_2);
						
						$ville['city']=$resultat['name'];
						$ville['country']=$resultat_2['name'];
						return($ville);
					}
				}
				elseif($mode=='weather'){
					$sel_req.=";";
					//print($sel_req);
					$recordset=mysql_query($sel_req);
					while($resultat=mysql_fetch_array($recordset)){
						$sel_req_2="SELECT `name` FROM countryInfo WHERE `iso_alpha2`='".$resultat['country']."';";
						$recordset_2=mysql_query($sel_req_2);
						$resultat_2=mysql_fetch_array($recordset_2);

						$weather=$this->known_weather_city($resultat['name'], $resultat_2['name']);
						if($resultat['name']!='' && $weather['success']==true){
							$city_found=true;
							$sel_req_2="SELECT `name` FROM countryInfo WHERE `iso_alpha2`='".$resultat['country']."';";
							$recordset_2=mysql_query($sel_req_2);
							$resultat_2=mysql_fetch_array($recordset_2);

							$ville['city']=$resultat['name'];
							$ville['country']=$resultat_2['name'];
							$ville['weather_com_id']=$weather['weather_com_id'];
							return($ville);

						}
					}
				}
				$delta_k++;	
			}
		}
	}
?>