<?php
	require_once(dirname(__FILE__).'/../geoservice-config.incl.php');
	require_once('db.incl.php');
	require_once('geoservice.incl.php');
?>