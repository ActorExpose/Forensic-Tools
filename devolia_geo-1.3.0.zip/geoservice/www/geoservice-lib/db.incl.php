<?php
	/**
	 *	DB Connection
	 *	@package geoservice
	 */
	
	function db_connect(){
		$link=@mysql_connect(GEOSERVICE_DB_HOST, GEOSERVICE_DB_USER, GEOSERVICE_DB_PASSWORD);
		if(!$link){
			//print('Could not connect to MySQL server on '.GEOSERVICE_DB_HOST.' with login '.GEOSERVICE_DB_USER.': ' . mysql_error());
			return(false);
		}
		else{
			$db=mysql_select_db(GEOSERVICE_DB_NAME, $link);
			if(!$db){
				//print('Could not connect to database '.GEOSERVICE_DB_NAME);
				return(false);	
			}
			else{
				mysql_set_charset('utf8',$link);
				return(true);	
			}
		}
	}
?>