<?php
	require_once('geoservice-config.incl.php');
	$main=file_get_contents('geoservice-assets/templates/main.tpl');

	// Version check
	$last_version=file_get_contents('http://devolia.org/latest_version.php?codename=geoservice');
	$last_version_int=(int)str_replace('.','',$last_version);
	$cur_version=GEOSERVICE_VERSION;
	$cur_version_int=(int)str_replace('.','',GEOSERVICE_VERSION);
	
	if($last_version_int>$cur_version_int){ $version='<strong>A new version ('.$last_version.') is available on <a href="http://devolia.org/projects/devolia_geo.html">devolia.org</a>. You currently run '.$cur_version.'</strong><br /><br /><div style="border-top:1px solid #ccc; height:1px; width:578px;"> </div><br />'; }
	if($last_version_int<$cur_version_int){ $version='<strong>You run a newer version ('.$cur_version.') than the lastest ('.$last_version.') available on <a href="http://devolia.org/projects/devolia_geo.html">devolia.org</a>.<br />You must be a beta-tester or some ninja!</strong><br /><br /><div style="border-top:1px solid #ccc; height:1px; width:578px;"> </div><br />'; }
	if($last_version_int==$cur_version_int){ $version=''; }

	$replace=array(	'{VERSION}'=>$version,
				   	'{CUR_IP}'=>$_SERVER['REMOTE_ADDR']
				   );
	foreach($replace as $key=>$value){ $main=str_replace($key, $value, $main); }
	print($main);
?>