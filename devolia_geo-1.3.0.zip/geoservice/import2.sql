USE `devolia_geo`;

DROP TABLE IF EXISTS blocks;
CREATE TABLE blocks (
startIpNum INT(15) UNSIGNED NOT NULL,
endIpNum INT(10) UNSIGNED NOT NULL,
locId INT(15) UNSIGNED NOT NULL
);
 
DROP TABLE IF EXISTS location;
CREATE TABLE location(
locId int(10) unsigned NOT NULL,
country char(2) NOT NULL,
region char(2) NOT NULL,
city varchar(50),
postalCode char(5) NOT NULL,
latitude float,
longitude float,
dmaCode integer,
areaCode integer,
PRIMARY KEY (locId)
);

LOAD DATA LOCAL INFILE 'GeoLiteCity_20101201/GeoLiteCity-Blocks.csv' INTO TABLE `blocks` FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE 'GeoLiteCity_20101201/GeoLiteCity-Location.csv' INTO TABLE `location` FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\n';

ALTER TABLE `blocks` ADD INDEX ( `startIpNum` );
ALTER TABLE `blocks` ADD INDEX ( `endIpNum` );