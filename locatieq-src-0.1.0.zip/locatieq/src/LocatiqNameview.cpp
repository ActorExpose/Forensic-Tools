/*
* ============================================================================
*  Name     : CLocatiqView from LocatiqView.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <AknQueryDialog.h> //CAknTextQueryDialog
#include <AknNoteDialog.h>
#include  <locatieq.rsg>
#include  "LocatiqNameView.h"
#include  "locatiq.hrh"
#include  "locatiqdb.h"
#include  "LocatiqNameContainer.h" 

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqView::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void CLocatiqNameView::ConstructL(CLocatiqDb *aLocate)
    {
    BaseConstructL( R_LOCATIQ_VIEWNAME );
	iLocate=aLocate;
    }

// ---------------------------------------------------------
// CLocatiqView::~CLocatiqView()
// ?implementation_description
// ---------------------------------------------------------
//
CLocatiqNameView::~CLocatiqNameView()
    {

	
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
	
    delete iContainer;
    }

// ---------------------------------------------------------
// TUid CLocatiqView::Id()
// ?implementation_description
// ---------------------------------------------------------
//
TUid CLocatiqNameView::Id() const
    {
    return KNameViewId;
    }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqNameView::HandleCommandL(TInt aCommand)
    {   
    switch ( aCommand )
        {
		case ElocatiqCmdRename:
			{
				CAknTextQueryDialog* dlg;
				TBuf<KNameLocalMaxLength> textData;
				iContainer->GetSelected(textData);
				dlg = new(ELeave)CAknTextQueryDialog(textData, CAknQueryDialog::ENoTone );
				dlg->SetMaxLength(KNameLocalMaxLength);
				TBool answer( dlg->ExecuteLD( R_LOCATIQ_DATA_QUERY) );
				if (answer){
					TInt id=iLocate->GetLACIdL(textData);
					if (id==-1){
						TBuf<KNameLocalMaxLength> buf;
						id=iLocate->GetLACIdL(buf);
						iLocate->UpdateLocalName(textData,id);
						CDesCArray* arr=iLocate->GetLocalsL();
						iContainer->SetLacList(arr);
					}
				}
			}
			break;
		case ElocatiqCmdDetail:
			{
				TBuf<KNameLocalMaxLength> buf;
				iContainer->GetSelected(buf);
				TInt id=iLocate->GetLACIdL(buf);
				TNetworkInfo ni;
				iLocate->GetNetworkInfo(ni,id);
				
				TBuf<128> msg;
				msg.Append(ni.iLacName);
				msg.AppendFormat(_L("\nLAC: %d\n"),ni.iLAC);
				msg.Append(ni.iShortName);
				CAknNoteDialog* dlg = new( ELeave ) CAknNoteDialog( 
					CAknNoteDialog::ENoTone, CAknNoteDialog::ENoTimeout);
				dlg->PrepareLC( R_SELECT_MESSAGE_NOTE );
				dlg->SetTextPluralityL( EFalse );
				dlg->SetTextL( msg );
				dlg->RunLD();
			}
			break;
		case ElocatiqCmdRefresh:
		case ElocatiqCmdDelete:
        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
    }

// ---------------------------------------------------------
// CLocatiqView::HandleClientRectChange()
// ---------------------------------------------------------
//
void CLocatiqNameView::HandleClientRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect( ClientRect() );
        }
    }

// ---------------------------------------------------------
// CLocatiqView::DoActivateL(...)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqNameView::DoActivateL(
   const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
   const TDesC8& /*aCustomMessage*/)
    {
    if (!iContainer)
        {
        iContainer = new (ELeave) CLocatiqNameContainer;
        iContainer->SetMopParent(this);
        iContainer->ConstructL( ClientRect() );
		AppUi()->AddToStackL( *this, iContainer );
		CDesCArray* arr=iLocate->GetLocalsL();
		iContainer->SetLacList(arr);
        } 
   }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqNameView::DoDeactivate()
    {
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
    
    delete iContainer;
    iContainer = NULL;
    }

// End of File

