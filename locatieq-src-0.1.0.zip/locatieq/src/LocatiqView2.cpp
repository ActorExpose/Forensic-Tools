/*
* ============================================================================
*  Name     : CLocatiqView2 from LocatiqView2.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <eikmenub.h> //menu bar
#include  <locatieq.rsg>
#include  "Locatiq.hrh"
#include  "LocatiqView2.h"
#include  "LocatiqContainer2.h" 
#include  "locatiqdb.h"

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqView2::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void CLocatiqView2::ConstructL(CLocatiqDb* aLocal)
    {
    BaseConstructL( R_LOCATIQ_VIEW2 );
	iLocal=aLocal;
    }

// ---------------------------------------------------------
// CLocatiqView2::~CLocatiqView2()
// ?implementation_description
// ---------------------------------------------------------
//
CLocatiqView2::~CLocatiqView2()
    {
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }

    delete iContainer;
    }

// ---------------------------------------------------------
// TUid CLocatiqView2::Id()
// ?implementation_description
// ---------------------------------------------------------
//
TUid CLocatiqView2::Id() const
    {
    return KView2Id;
    }

// ---------------------------------------------------------
// CLocatiqView2::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView2::HandleCommandL(TInt aCommand)
    {   
    switch ( aCommand )
        {
		case ElocatiqCmdEdit:
			{
			iContainer->SetEditable(ETrue);
			
			CEikMenuBar* menuBar = MenuBar();//iEikonEnv->AppUiFactory()->MenuBar();
			
			menuBar->StopDisplayingMenuBar();
			menuBar->SetMenuTitleResourceId(R_LOCATIQ_MENUBAR_VIEW22);
			}          
			//MakeVisible(ETrue);
			break;
		case ElocatiqCmdSave:
			{
			TBuf<KDescriptionMaxLength> tmp;
			iContainer->GetText(tmp);
			iLocal->UpdateCellDescriptioL(tmp);
			}
		case ElocatiqCmdCancel:
			{
			iContainer->SetEditable(EFalse);
			CEikMenuBar* menuBar = MenuBar();//iEikonEnv->AppUiFactory()->MenuBar();
			
			menuBar->StopDisplayingMenuBar();
			menuBar->SetMenuTitleResourceId(R_LOCATIQ_MENUBAR_VIEW2);
			}
			break;
        case ElocatiqCmdSend:
            {
            iEikonEnv->InfoMsg( _L("Send") );
            break;
            }
        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
    }

// ---------------------------------------------------------
// CLocatiqView2::HandleClientRectChange()
// ---------------------------------------------------------
//
void CLocatiqView2::HandleClientRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect( ClientRect() );
        }
    }

// ---------------------------------------------------------
// CLocatiqView2::DoActivateL(...)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView2::DoActivateL(
   const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
   const TDesC8& /*aCustomMessage*/)
    {
    if (!iContainer)
        {
        iContainer = new (ELeave) CLocatiqContainer2;
        iContainer->SetMopParent(this);
        iContainer->ConstructL( ClientRect() );
		AppUi()->AddToStackL( *this, iContainer );
		TBuf<KDescriptionMaxLength>desc;
		iLocal->GetCellDescL(desc);
		TPtrC tmp;
		tmp.Set(desc);
		iContainer->SetTextL(&tmp);
        }
   }

// ---------------------------------------------------------
// CLocatiqView2::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView2::DoDeactivate()
    {
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
    
    delete iContainer;
    iContainer = NULL;
    }

// End of File

