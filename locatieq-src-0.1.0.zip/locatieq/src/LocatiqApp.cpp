/*
* ============================================================================
*  Name     : CLocatiqApp from LocatiqApp.cpp
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include    "LocatiqApp.h"
#include    "LocatiqDocument.h"

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqApp::AppDllUid()
// Returns application UID
// ---------------------------------------------------------
//
TUid CLocatiqApp::AppDllUid() const
    {
    return KUidlocatiq;
    }

   
// ---------------------------------------------------------
// CLocatiqApp::CreateDocumentL()
// Creates CLocatiqDocument object
// ---------------------------------------------------------
//
CApaDocument* CLocatiqApp::CreateDocumentL()
    {
    return CLocatiqDocument::NewL( *this );
    }

// ================= OTHER EXPORTED FUNCTIONS ==============
//
// ---------------------------------------------------------
// NewApplication() 
// Constructs CLocatiqApp
// Returns: created application object
// ---------------------------------------------------------
//
EXPORT_C CApaApplication* NewApplication()
    {
    return new CLocatiqApp;
    }

// ---------------------------------------------------------
// E32Dll(TDllReason) 
// Entry point function for EPOC Apps
// Returns: KErrNone: No error
// ---------------------------------------------------------
//
GLDEF_C TInt E32Dll( TDllReason )
    {
    return KErrNone;
    }

// End of File  

