/*
* ============================================================================
*  Name     : CLocatiqContainer from LocatiqContainer.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include <aknlists.h> //CAknSingleLargeStyleListBox
#include <badesca.h>  //CDesCArray
#include "LocatiqContainer.h"


_LIT(KListMCC,"MCC\t%d\t\t");
_LIT(KListMNC,"MNC\t%d\t\t");
_LIT(KListLAC,"LAC\t%d\t\t");
_LIT(KListCID,"CellId\t%d\t\t");
_LIT(KListShort,"Short\t");
_LIT(KListLong,"Long\t");


// ================= MEMBER FUNCTIONS =======================
// ---------------------------------------------------------
// CLocatiqContainer::ConstructL(const TRect& aRect)
// EPOC two phased constructor
// ---------------------------------------------------------
//
void CLocatiqContainer::ConstructL(const TRect& aRect)
    {
    CreateWindowL();

    iList = new (ELeave) CAknSingleHeadingStyleListBox;
	iList->SetContainerWindowL(*this);
	// construct listbox
	iList->ConstructL(this, EAknListBoxSelectionList);
	// set container control
	// add scrollbars to listbox
	
	iList->CreateScrollBarFrameL(ETrue);
	iList->ScrollBarFrame()->SetScrollBarVisibilityL(CEikScrollBarFrame::EOn, CEikScrollBarFrame::EAuto );
	iList->ActivateL();
	CDesCArray *itemList = new (ELeave) CDesCArrayFlat(6);
	iList->Model()->SetOwnershipType(ELbmOwnsItemArray);
	iList->Model()->SetItemTextArray(itemList);
	SetNetworkInfo(0,0,0,0,_L(""),_L(""));
	// update listbox
    SetRect(aRect);
    ActivateL();
    }

// Destructor
CLocatiqContainer::~CLocatiqContainer()
    {
    delete iList;
    }

// ---------------------------------------------------------
// CLocatiqContainer::SizeChanged()
// Called by framework when the view size is changed
// ---------------------------------------------------------
//
void CLocatiqContainer::SizeChanged()
    {
    // TODO: Add here control resize code etc.
    iList->SetRect( Rect() );
    }

// ---------------------------------------------------------
// CLocatiqContainer::CountComponentControls() const
// ---------------------------------------------------------
//
TInt CLocatiqContainer::CountComponentControls() const
    {
    return 1; // return nbr of controls inside this container
    }

// ---------------------------------------------------------
// CLocatiqContainer::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* CLocatiqContainer::ComponentControl(TInt aIndex) const
    {
    switch ( aIndex )
        {
        case 0:
            return iList;
        default:
            return NULL;
        }
    }

// ---------------------------------------------------------
// CLocatiqContainer::Draw(const TRect& aRect) const
// ---------------------------------------------------------
//
void CLocatiqContainer::Draw(const TRect& aRect) const
    {
    CWindowGc& gc = SystemGc();
    // TODO: Add your drawing code here
    // example code...
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    gc.SetBrushColor(KRgbGray);
    gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);
    }

// ---------------------------------------------------------
// CLocatiqContainer::HandleControlEventL(
//     CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void CLocatiqContainer::HandleControlEventL(
    CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
    {
    // TODO: Add your control event handler code here
    }

TKeyResponse CLocatiqContainer::OfferKeyEventL(
    const TKeyEvent& aKeyEvent,
    TEventCode aType )
    {
    if ( aType != EEventKey ) // Is not key event?
        {
        return EKeyWasNotConsumed;
        }
	
	switch ( aKeyEvent.iCode )
        {
        case EKeyLeftArrow:
        case EKeyRightArrow:
            return EKeyWasNotConsumed;
        }

	return iList->OfferKeyEventL( aKeyEvent, aType );
    }


void CLocatiqContainer::SetNetworkInfo(TUint aMCC, TUint aMNC,TUint aLAC, TUint aCID,const TDesC& aShortName, const TDesC& aLongName)
{
	
	MDesCArray* textArray = iList->Model()->ItemTextArray();
	CDesCArray* itemList = static_cast<CDesCArray*>(textArray);
	//CleanupStack::PushL(itemList);
	itemList->Reset();
	TBuf<62> item;
	// append items to the listbox, incrementing numbering
	
	item.Format(KListMCC, aMCC);
	//itemList->MdcaPoint(0).Set(item);
	itemList->InsertL(0,item);
	item.Format(KListMNC, aMNC);
	itemList->InsertL(1,item);
	item.Format(KListLAC, aLAC);
	itemList->InsertL(2,item);
	item.Format(KListCID, aCID);
	itemList->InsertL(3,item);
	item.Zero();
	item.Append(KListShort);
	item.Append(aShortName);
	itemList->InsertL(4,item);
	item.Zero();
	item.Append(KListLong);
	item.Append(aLongName);
	itemList->InsertL(5,item);
	// update listbox
	iList->HandleItemAdditionL();
	//CleanupStack::PopAndDestroy(itemList);
}
// End of File  
