/*
* ============================================================================
*  Name     : CLocatiqView from LocatiqView.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <locatieq.rsg>
#include  "LocatiqView.h"
#include  "locatiq.hrh"
#include  "locatiqdb.h"
#include  "LocatiqContainer.h" 

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqView::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void CLocatiqView::ConstructL(CLocatiqDb *aLocate)
    {
    BaseConstructL( R_LOCATIQ_VIEW1 );
	iLocate=aLocate;
    }

// ---------------------------------------------------------
// CLocatiqView::~CLocatiqView()
// ?implementation_description
// ---------------------------------------------------------
//
CLocatiqView::~CLocatiqView()
    {

	
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
	
    delete iContainer;
    }

// ---------------------------------------------------------
// TUid CLocatiqView::Id()
// ?implementation_description
// ---------------------------------------------------------
//
TUid CLocatiqView::Id() const
    {
    return KViewId;
    }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView::HandleCommandL(TInt aCommand)
    {   
    switch ( aCommand )
        {
		case ElocatiqCmdRefresh:
			GetLocation();
			break;
        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
    }

// ---------------------------------------------------------
// CLocatiqView::HandleClientRectChange()
// ---------------------------------------------------------
//
void CLocatiqView::HandleClientRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect( ClientRect() );
        }
    }

// ---------------------------------------------------------
// CLocatiqView::DoActivateL(...)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView::DoActivateL(
   const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
   const TDesC8& /*aCustomMessage*/)
    {
    if (!iContainer)
        {
        iContainer = new (ELeave) CLocatiqContainer;
        iContainer->SetMopParent(this);
        iContainer->ConstructL( ClientRect() );
		AppUi()->AddToStackL( *this, iContainer );
		GetLocation();
        } 
   }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqView::DoDeactivate()
    {
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
    
    delete iContainer;
    iContainer = NULL;
    }

void CLocatiqView::GetLocation()
{
	iLocate->RefreshLocationL();
	iContainer->SetNetworkInfo(iLocate->MCC(),
		iLocate->MNC(),
		iLocate->LAC(),
		iLocate->CellId(),
		iLocate->ShortName(),
		iLocate->LongName());
}
// End of File

