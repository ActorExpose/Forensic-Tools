/*
* ============================================================================
*  Name     : CLocatiqDb from LocatiqDb.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/
#include <bautils.h>

#include "LocatiqDb.h"

// Constants
_LIT(KNetworkTable, "Network");
_LIT(KNetworkIndex, "NetworkIndex");
_LIT(KMncCol, "MNC");
_LIT(KShortCol, "Short");
_LIT(KLongCol, "Long");

_LIT(KLocalTable, "Local");
_LIT(KLocalIndex, "LocalIndex");
_LIT(KLacIdCol, "idLAC");
_LIT(KLacCol, "LAC");
_LIT(KNameLacCol, "NameLAC");

_LIT(KCellsTable, "Cell");
_LIT(KCellsIndex, "CellIndex");
_LIT(KIdCol, "id");
_LIT(KCellIdCol, "CellId");
_LIT(KLastCol, "lastTime");
_LIT(KFirstCol, "firstTime");
_LIT(KNameCol, "Name");
_LIT(KCellsDescriptionCol, "desc");
_LIT(KGsmModuleName, "phonetsy.tsy");


_LIT(KNewLocalName, "lac-%d");
_LIT(KNewCellName, "cell-%d");

const int KCustomSqlMaxLength = 256;
const int KArrayGranularity = 5;     // for CDesCArrayFlat

CLocatiqDb* CLocatiqDb::NewL()
    {
    CLocatiqDb* tmp = new (ELeave)CLocatiqDb();
    CleanupStack::PushL(tmp);
    tmp->ConstructL();
    CleanupStack::Pop();
    return tmp;
    }

CLocatiqDb::CLocatiqDb()
{
	iOpen = EFalse;
	iCurrentIdCell = -1;
	iCurrentIdLac  = -1;
}

CLocatiqDb::~CLocatiqDb()
{
	
	Close();
	iFsSession.Close();

	iPhone.Close();
	iServer.UnloadPhoneModule( KGsmModuleName );

	iServer.Close();
}

void CLocatiqDb::ConstructL(){
	User::LeaveIfError( iServer.Connect() );
	// load a phone profile

	User::LeaveIfError( iServer.LoadPhoneModule( KGsmModuleName ) );

	TInt err = iFsSession.Connect();
	User::LeaveIfError(err );
}

void CLocatiqDb::RefreshLocationL()
{
	RTelServer::TPhoneInfo info;
	User::LeaveIfError( iServer.GetPhoneInfo( 0, info ) );
	User::LeaveIfError( iPhone.Open( iServer, info.iName ) );

	MBasicGsmPhoneNetwork::TCurrentNetworkInfo ni;
	User::LeaveIfError( iPhone.GetCurrentNetworkInfo( ni ) );
	iNetworkInfo.iMCC = ni.iNetworkInfo.iId.iMCC;
	iNetworkInfo.iMNC = ni.iNetworkInfo.iId.iMNC;
	iNetworkInfo.iLAC = ni.iLocationAreaCode;
	iNetworkInfo.iCellId = ni.iCellId;
#ifdef __WINS__
	iCellId=(iCellId<5)?1+iCellId:1;
	iNetworkInfo.iCellId = iCellId;
#endif
	iNetworkInfo.iShortName.Copy(ni.iNetworkInfo.iShortName);
	iNetworkInfo.iLongName.Copy(ni.iNetworkInfo.iLongName);
	iPhone.Close();
	AddLocalL();

}


// ---------------------------------------------------------------------------
// CBookstoreDb::OpenDbL()
//
// Open existing bookstore database for exclusive access.
// ---------------------------------------------------------------------------
TInt CLocatiqDb::OpenDbL(const TFileName& aExistingFile)
    {
    Close();

    if(!BaflUtils::FileExists(iFsSession, aExistingFile))
        {
            return KErrNotFound;
        }

    iFileStore = CPermanentFileStore::OpenL(iFsSession,
        aExistingFile, EFileRead|EFileWrite);
    iFileStore->SetTypeL(iFileStore->Layout());       // Set file store type
    iLocalDb.OpenL(iFileStore,iFileStore->Root());
    iOpen = ETrue;
    return KErrNone;
    }

// ---------------------------------------------------------------------------
// CBookstoreDb::CreateDbL()
//
// Create a new database. The database will be in exclusive access mode.
// ---------------------------------------------------------------------------
TInt CLocatiqDb::CreateDbL(const TFileName& aNewFile)
    {
    Close();

    // Create empty database file.
    iFileStore = CPermanentFileStore::ReplaceL(iFsSession,
        aNewFile, EFileRead|EFileWrite);
    iFileStore->SetTypeL(iFileStore->Layout());       // Set file store type
    TStreamId id = iLocalDb.CreateL(iFileStore);  // Create stream object
    iFileStore->SetRootL(id);            // Keep database id as root of store
    iFileStore->CommitL();               // Complete creation by commiting

    // Create bookstore tables and indexes
    CreateNetworkTableL();
    CreateNetworkIndexL();
	CreateLocalTableL();
    CreateLocalIndexL();

	CreateCellsTableL();
    CreateCellsIndexL();
    iOpen = ETrue;
    return KErrNone;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::RemoveDbL()
//
// First remove the Books table. Then remove the database file.
// ---------------------------------------------------------------------------
TInt CLocatiqDb::RemoveDbL(const TFileName& aExistingFile)
    {
    Close();

    if(!BaflUtils::FileExists(iFsSession, aExistingFile))
        {
            return KErrNotFound;
        }

    // It is enough to delete the database file directly. Because this example
    // demonstrates DDL statements, it first opens and drops the Books table.

    OpenDbL(aExistingFile);
    DropTableL(KNetworkTable);
	DropTableL(KLocalTable);
	DropTableL(KCellsTable);
    Close();

    iFsSession.Delete(aExistingFile);
    return KErrNone;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::Close()
//
// Close the database.
// ---------------------------------------------------------------------------
TInt CLocatiqDb::Close()
    {
    iLocalDb.Close();
    if(iFileStore)
        {
        delete iFileStore;
        iFileStore = NULL;
        }
    iOpen = EFalse;
    return KErrNone;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::IsOpen()
//
// Return open status of the database.
// ---------------------------------------------------------------------------
TBool CLocatiqDb::IsOpen() const
    {
    return iOpen;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::CreateBooksTableL()
//
// Creates Books table. Leaves, if the table cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateNetworkTableL()
    {

    // Specify columns for Books table
	TDbCol mncCol(KMncCol, EDbColUint32);   // Using default length
	TDbCol shortCol(KShortCol, EDbColText,MBasicGsmPhoneNetwork::KShortNetworkNameSize);
	TDbCol longCol(KLongCol, EDbColText,MBasicGsmPhoneNetwork::KLongNetworkNameSize);

    // Add the columns to column set
    CDbColSet* bookColSet = CDbColSet::NewLC();
    bookColSet->AddL(mncCol);
    bookColSet->AddL(shortCol);
	bookColSet->AddL(longCol);

    // Create the Books table
    User::LeaveIfError(iLocalDb.CreateTable(KNetworkTable,
        *bookColSet));
    CleanupStack::PopAndDestroy(bookColSet);
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::CreateNetworkIndexL()
//
// Creates an index for Books table. Leaves, if the index cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateNetworkIndexL()
    {
    // Create index consisting of two columns
    TDbKeyCol mncCol(KMncCol);

    CDbKey* index = CDbKey::NewLC();   // create index key set
    index->AddL(mncCol);
    User::LeaveIfError(iLocalDb.CreateIndex(
        KNetworkIndex, KNetworkTable, *index));
    CleanupStack::PopAndDestroy(index);
    }
// ---------------------------------------------------------------------------
// CLocatiqDb::CreateBooksTableL()
//
// Creates Books table. Leaves, if the table cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateLocalTableL()
    {

    // Specify columns for Books table
    TDbCol idCol(KLacIdCol, EDbColUint16);   // Using default length
	idCol.iAttributes = TDbCol::EAutoIncrement;
	TDbCol mncCol(KMncCol,EDbColUint32);
	TDbCol lacCol(KLacCol, EDbColUint16);   // Using default length
	TDbCol nameCol(KNameLacCol, EDbColText,KNameLocalMaxLength);

    // Add the columns to column set
    CDbColSet* bookColSet = CDbColSet::NewLC();
	bookColSet->AddL(idCol);
    bookColSet->AddL(mncCol);
	bookColSet->AddL(lacCol);
    bookColSet->AddL(nameCol);

    // Create the Books table
    User::LeaveIfError(iLocalDb.CreateTable(KLocalTable,
        *bookColSet));
    CleanupStack::PopAndDestroy(bookColSet);
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::CreateNetworkIndexL()
//
// Creates an index for Books table. Leaves, if the index cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateLocalIndexL()
    {
    // Create index consisting of two columns
    TDbKeyCol mncCol(KMncCol);
	TDbKeyCol laccCol(KLacCol);
	TDbKeyCol nameCol(KNameLacCol);

    CDbKey* index = CDbKey::NewLC();   // create index key set
    index->AddL(mncCol);
	index->AddL(laccCol);
	index->AddL(nameCol);
    User::LeaveIfError(iLocalDb.CreateIndex(
        KLocalIndex, KLocalTable, *index));
    CleanupStack::PopAndDestroy(index);
    }


// ---------------------------------------------------------------------------
// CLocatiqDb::CreateBooksTableL()
//
// Creates Books table. Leaves, if the table cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateCellsTableL()
    {

    // Specify columns for Books table
    TDbCol idCol(KIdCol, EDbColUint16);   // Using default length
	idCol.iAttributes = TDbCol::EAutoIncrement;
	TDbCol lacCol(KLacIdCol,EDbColUint16);
	TDbCol cellidCol(KCellIdCol, EDbColUint16);   // Using default length
	TDbCol firstCol(KFirstCol, EDbColDateTime);   // Using default length
	TDbCol lastCol(KLastCol, EDbColDateTime);   // Using default length
	TDbCol nameCol(KNameCol, EDbColText,KNameLocalMaxLength);
	TDbCol descriptionCol(KCellsDescriptionCol, EDbColLongText); // Stream Data

    // Add the columns to column set
    CDbColSet* bookColSet = CDbColSet::NewLC();
	bookColSet->AddL(idCol);
	bookColSet->AddL(lacCol);
    bookColSet->AddL(cellidCol);
	bookColSet->AddL(firstCol);
	bookColSet->AddL(lastCol);
    bookColSet->AddL(nameCol);
	bookColSet->AddL(descriptionCol);

    // Create the Books table
    User::LeaveIfError(iLocalDb.CreateTable(KCellsTable,
        *bookColSet));
    CleanupStack::PopAndDestroy(bookColSet);
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::CreateNetworkIndexL()
//
// Creates an index for Books table. Leaves, if the index cannot be created.
// ---------------------------------------------------------------------------
void CLocatiqDb::CreateCellsIndexL()
    {
    // Create index consisting of two columns
    TDbKeyCol celIdCol(KCellIdCol);
	TDbKeyCol nameCol(KNameCol);

    CDbKey* index = CDbKey::NewLC();   // create index key set
    index->AddL(celIdCol);
	index->AddL(nameCol);
    User::LeaveIfError(iLocalDb.CreateIndex(
        KCellsIndex, KCellsTable, *index));
    CleanupStack::PopAndDestroy(index);
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::DropNetworkTableL()
//
// Drop the Books table incrementally. Uses RDbIncremental and DDL statement.
// ---------------------------------------------------------------------------
void CLocatiqDb::DropTableL(const TDesC& aTable)
    {
    _LIT(KDropTable, "DROP TABLE ");

    // Sql: DROP TABLE Books
    TBuf<KCustomSqlMaxLength> sqlStr;
    sqlStr.Append(KDropTable);
    sqlStr.Append(aTable);

    RDbIncremental incOp;
    TInt incStep = 0xFFFF;
    // Initialise Execution
    TInt incStat = incOp.Execute(iLocalDb, sqlStr, incStep);
    while (incStep>0 && incStat==KErrNone)
        {
        incStat = incOp.Next(incStep); // Do the work
        }
    incOp.Close();
    }

// ---------------------------------------------------------------------------
// CBookstoreDb::AddBookWithCppApiL()
//
// Add a book to database using RDbTable API
// ---------------------------------------------------------------------------
TInt CLocatiqDb::AddLocalL()
    {
    
	TInt32 mnc=iNetworkInfo.iMCC*1000+iNetworkInfo.iMNC;
	TInt32 id=GetLACIdL(iNetworkInfo.iLAC,mnc);
	RDbTable table;
	CDbColSet* booksColSet;
	TBuf<KNameLocalMaxLength> newname;
	TInt err;
	TBool isnew=ETrue;
	if (id==-1){
		if (!isMNCExistL(mnc)){
			err = table.Open(iLocalDb, KNetworkTable, table.EUpdatable);
			User::LeaveIfError(err);
			booksColSet = table.ColSetL();
			CleanupStack::PushL(booksColSet);
	
			table.Reset();
			table.InsertL();
			table.SetColL(booksColSet->ColNo(KMncCol), mnc); // col = 1
			table.SetColL(booksColSet->ColNo(KShortCol), iNetworkInfo.iShortName); // col = 1
			table.SetColL(booksColSet->ColNo(KLongCol), iNetworkInfo.iLongName); // col = 1
	
			CleanupStack::PopAndDestroy(booksColSet);

			table.PutL();    // Complete changes (the insertion)
			table.Close();
		}
		err = table.Open(iLocalDb, KLocalTable, table.EUpdatable);
		User::LeaveIfError(err);

		booksColSet = table.ColSetL();
		CleanupStack::PushL(booksColSet);
	
		newname.Format(KNewLocalName,iNetworkInfo.iLAC);
		table.Reset();
		table.InsertL();
		table.SetColL(booksColSet->ColNo(KMncCol), mnc);
		table.SetColL(booksColSet->ColNo(KLacCol), iNetworkInfo.iLAC);
		table.SetColL(booksColSet->ColNo(KNameLacCol),newname);

		CleanupStack::PopAndDestroy(booksColSet);

		table.PutL();    // Complete changes (the insertion)
		table.Close();
		id=GetLACIdL(iNetworkInfo.iLAC, mnc);
	} else {
		isnew=EFalse;
	}
	// Create an updateable database table object
	TInt32 idCell=-1;
	if (!isnew)idCell=GetCellIdL(iNetworkInfo.iCellId, id);
	
	if (idCell == -1){
		err = table.Open(iLocalDb, KCellsTable, table.EUpdatable);
		User::LeaveIfError(err);

		booksColSet = table.ColSetL();
		CleanupStack::PushL(booksColSet);
	
		newname.Format(KNewCellName,iNetworkInfo.iCellId);
		TTime time;
		time.HomeTime();

		table.Reset();
		table.InsertL();
		table.SetColL(booksColSet->ColNo(KLacIdCol), id);
		table.SetColL(booksColSet->ColNo(KCellIdCol), iNetworkInfo.iCellId);
		table.SetColL(booksColSet->ColNo(KFirstCol), time.DateTime());
		table.SetColL(booksColSet->ColNo(KLastCol), time.DateTime());
		table.SetColL(booksColSet->ColNo(KNameCol),newname);

		CleanupStack::PopAndDestroy(booksColSet);

		table.PutL();    // Complete changes (the insertion)
		table.Close();
		idCell=GetCellIdL(iNetworkInfo.iCellId,id);
	}
	iCurrentIdCell = idCell;
	iCurrentIdLac =id;
	return KErrNone;
    }

// ---------------------------------------------------------------------------
// CBookstoreDb::UpdateBookTitle()
//
// Update book title using SQL UPDATE.
// ---------------------------------------------------------------------------
//
TInt CLocatiqDb::UpdateLocalName(const TDesC& aName,TInt32 aLac)
    {
	TInt err=KErrNone;
    if (-1==aLac){
		aLac=iCurrentIdLac;
	}
	TBuf<KCustomSqlMaxLength> sqlStr;
    sqlStr.Format(_L("SELECT NameLAC From Local Where idLac=%d"),aLac);
    
    RDbView view;    // Create a view on the database
    User::LeaveIfError(
        view.Prepare(iLocalDb, TDbQuery(sqlStr)));
    User::LeaveIfError(view.EvaluateAll());

	CDbColSet* colSet = view.ColSetL();
    CleanupStack::PushL(colSet);
	view.FirstL();
	if (view.AtRow()){
		view.GetL();
		view.UpdateL();  // Update a row. Colum
		view.SetColL(colSet->ColNo(KNameLacCol), aName); // col = 1
		view.PutL();     // Complete insertion
	} else {
		err=-1; //not found
	}
	CleanupStack::PopAndDestroy(colSet);
    view.Close();
	return err;
    }

// ---------------------------------------------------------------------------
// CBookstoreDb::UpdateBookTitle()
//
// Update book title using SQL UPDATE.
// ---------------------------------------------------------------------------
//
TInt CLocatiqDb::UpdateCellName(const TDesC& aName,TUint32 aId)
    {
	TInt err=KErrNone;
	if (-1==aId){
		aId=iCurrentIdCell;
	}
	TBuf<KCustomSqlMaxLength> sqlStr;
    sqlStr.Format(_L("SELECT Name From Cell Where id=%d"),aId);
    
    RDbView view;    // Create a view on the database
    User::LeaveIfError(
        view.Prepare(iLocalDb, TDbQuery(sqlStr)));
    User::LeaveIfError(view.EvaluateAll());

	CDbColSet* colSet = view.ColSetL();
    CleanupStack::PushL(colSet);
	view.FirstL();
	if (view.AtRow()){
		view.GetL();
		view.UpdateL();  // Update a row. Colum
		view.SetColL(colSet->ColNo(KNameCol), aName); // col = 1
		view.PutL();     // Complete insertion
	} else {
		err=-1; //not found
	}
	CleanupStack::PopAndDestroy(colSet);
    view.Close();
	return err;
    }

TInt CLocatiqDb::UpdateCellDescriptioL(const TDesC& aDesc,TInt32 aId)
{
	if (-1==aId){
		aId=iCurrentIdCell;
	}
	TBuf<KCustomSqlMaxLength> sqlStr;
    sqlStr.Format(_L("SELECT desc From Cell Where id=%d"),aId);
    
    RDbView view;    // Create a view on the database
    User::LeaveIfError(
        view.Prepare(iLocalDb, TDbQuery(sqlStr)));
    User::LeaveIfError(view.EvaluateAll());

	view.FirstL();
	if (view.AtRow()){
		view.GetL();
		view.UpdateL();  // Update a row. Colum
		RDbColWriteStream writeStream;  // Use stream to insert the description
		writeStream.OpenLC(view, 1);
		writeStream.WriteL(aDesc);
		CleanupStack::Pop();
		writeStream.Close();
		view.PutL();     // Complete insertion
	}
    view.Close();
	return KErrNone;
}
// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
CDesCArrayFlat* CLocatiqDb::GetLocalsL(TInt32 aMnc)
    {
    _LIT(KSQLQuery, "SELECT NameLAC FROM Local WHERE MNC=%d ORDER BY NameLAC");
    TBuf<KNameLocalMaxLength> rowText;
	TBuf<255> sqlText;
	
	if (aMnc == -1){
		aMnc=iNetworkInfo.iMCC*1000+iNetworkInfo.iMNC;
	}
	sqlText.Format(KSQLQuery,aMnc);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

    CDesCArrayFlat* resultArray =
        new (ELeave)CDesC16ArrayFlat(KArrayGranularity);
    CleanupStack::PushL(resultArray);

	view.FirstL();      
    while (view.AtRow()){
		rowText.Zero();
		view.GetL();
		rowText.Copy(_L("\t"));
		rowText.Append(view.ColDes(1));
		resultArray->AppendL(rowText); // Copy rowText to resultArray
        view.NextL();
    }
	view.Close();
    CleanupStack::Pop(resultArray);
    return resultArray;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
CDesCArrayFlat* CLocatiqDb::GetCellsL(TInt32 aLacId)
    {
    _LIT(KSQLQuery, "SELECT Name FROM Cell WHERE idLAC=%d ORDER BY lastTime DESC");
    TBuf<KNameLocalMaxLength> rowText;
	TBuf<255> sqlText;
	
	if (-1==aLacId){
		aLacId=iCurrentIdLac;
	}
	sqlText.Format(KSQLQuery,aLacId);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

    CDesCArrayFlat* resultArray =
        new (ELeave)CDesC16ArrayFlat(KArrayGranularity);
    CleanupStack::PushL(resultArray);

	view.FirstL();      
    while (view.AtRow()){
		rowText.Zero();
		view.GetL();
		rowText.Copy(_L("\t"));
		rowText.Append(view.ColDes(1));
		resultArray->AppendL(rowText); // Copy rowText to resultArray
        view.NextL();
    }
	view.Close();
    CleanupStack::Pop(resultArray);
    return resultArray;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// Get array of all books in database. Format of each array item is:
//      <Author>|<Title>|<Description>
// ---------------------------------------------------------------------------
CDesCArrayFlat* CLocatiqDb::GetCellsL(const TDesC& aLocal)
    {
	_LIT(KSQLQuery, "SELECT Cells.Name FROM Cell,Local WHERE Cells.idLAC=Local.idLAC AND NameLAC='");
	_LIT(KSQLQuery2, "' ORDER BY lastTime");
    TPtrC name;
    TBuf<KNameLocalMaxLength> rowText;
	TBuf<255> sqlText;
	
	sqlText.Copy(KSQLQuery);
	sqlText.Append(aLocal);
	sqlText.Append(KSQLQuery2);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

    CDesCArrayFlat* resultArray =
        new (ELeave)CDesC16ArrayFlat(KArrayGranularity);
    CleanupStack::PushL(resultArray);

	view.FirstL();      
    while (view.AtRow()){
		rowText.Zero();
		view.GetL();
		rowText.Copy(view.ColDes(1));
		resultArray->AppendL(rowText); // Copy rowText to resultArray
        view.NextL();
    }
	view.Close();
    CleanupStack::Pop(resultArray);
    return resultArray;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
TInt32 CLocatiqDb::GetLACIdL(TInt32 aLacID, TInt32 aMnc)
    {
    _LIT(KSQLQuery, "SELECT idLAC FROM Local WHERE MNC=%u AND LAC=%u");
	
	if (aLacID==-1){
		aLacID=iNetworkInfo.iLAC;
		aMnc=iNetworkInfo.iMCC*1000+iNetworkInfo.iMNC;
	}
	TBuf<KCustomSqlMaxLength> sqlText;
	sqlText.Format(KSQLQuery,aMnc,aLacID);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText),view.EReadOnly);
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

	if (view.CountL()==0)return -1;
	view.FirstL();
	view.AtRow();
	view.GetL();
	TUint r=view.ColUint16(1);
	view.Close();
	return r;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
TInt32 CLocatiqDb::GetLACIdL(const TDesC& aName)
    {
    _LIT(KSQLQuery, "SELECT idLAC FROM Local WHERE NameLAC='");
	_LIT(KSQLQuery1, "'");
	
	TBuf<KCustomSqlMaxLength> sqlText;
	sqlText.Copy(KSQLQuery);
	sqlText.Append(aName);
	sqlText.Append(KSQLQuery1);

	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText),view.EReadOnly);
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

	if (view.CountL()==0)return -1;
	view.FirstL();
	view.AtRow();
	view.GetL();
	TUint r=view.ColUint16(1);
	view.Close();
	return r;
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
TInt CLocatiqDb::GetCellDescL(TDes& aDes,TInt32 aId)
    {
	
    _LIT(KSQLQuery, "SELECT desc FROM Cell WHERE id=%u");
	if (-1==aId){
		aId=iCurrentIdCell;
	}
	TBuf<KDescriptionMaxLength> description;
	TBuf<KCustomSqlMaxLength> sqlText;
	sqlText.Format(KSQLQuery,aId);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

    view.FirstL();
	TInt r=-1;
	if (view.AtRow()){
		description.Zero();
        view.GetL();
        RDbColReadStream readStream;       // A stream object for long columns
        readStream.OpenLC(view,1);
        readStream.ReadL(description, view.ColLength(1));
        readStream.Close();
        CleanupStack::Pop(); //readStream
		aDes.Copy(description);
		r=0;
    }
	view.Close();
	return r;
}


TBool CLocatiqDb::isMNCExistL(TInt32 aMnc)
    {
    _LIT(KSQLQuery, "SELECT MNC FROM Network WHERE MNC=%d");
	TBuf<255> sqlText;
	if (-1==aMnc){
		aMnc=iNetworkInfo.iMCC*1000+iNetworkInfo.iMNC;
	}
	sqlText.Format(KSQLQuery,aMnc);
	
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);
	TBool r=(view.CountL()==0)?EFalse:ETrue;
	view.Close();
	return r;
	}

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
TInt32 CLocatiqDb::GetCellIdL(TInt32 aCellId, TInt32 aIdLac)
    {
    _LIT(KSQLQuery, "SELECT id FROM Cell WHERE idLAC=%u AND CellId=%u");
	TBuf<KCustomSqlMaxLength> sqlText;
	
	if (-1==aCellId){
		aCellId=iNetworkInfo.iCellId;
		aIdLac=iCurrentIdLac;
	}
	sqlText.Format(KSQLQuery,aIdLac,aCellId);
	//ColumnNamesAndSizes();
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

	if (view.CountL()==0)return -1;
	view.FirstL();
	view.AtRow();
	view.GetL();
	return view.ColUint16(1);
    }

// ---------------------------------------------------------------------------
// CLocatiqDb::GetAllLocalL()
//
// ---------------------------------------------------------------------------
TInt32 CLocatiqDb::GetCellIdL(const TDesC& aName)
    {
    _LIT(KSQLQuery, "SELECT id FROM Cell WHERE Name='");
	_LIT(KSQLQuery2, "'");
	TBuf<KCustomSqlMaxLength> sqlText;
	
	sqlText.Copy(KSQLQuery);
	sqlText.Append(aName);
	sqlText.Append(KSQLQuery2);
	//ColumnNamesAndSizes();
	RDbView view;

    TInt err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

	if (view.CountL()==0)return -1;
	view.FirstL();
	view.AtRow();
	view.GetL();
	return view.ColUint16(1);
    }


TInt CLocatiqDb::GetNetworkInfo(TNetworkInfo& info, TInt32 aLACId,TInt32 aCellId)
{
	_LIT(KSQLQueryLocal, "SELECT MNC,LAC,NameLAC FROM Local WHERE idLAC=%u");
	_LIT(KSQLQueryMNC, "SELECT Short,Long FROM Network WHERE MNC=%u");
	TBuf<KCustomSqlMaxLength> sqlText;
	
	RDbView view;
	TInt err;

	if (aCellId!=-1){
		_LIT(KSQLQueryCell, "SELECT idLAC,CellId,Name FROM Cell WHERE id=%u");
		sqlText.Format(KSQLQueryCell,aCellId);
		err = view.Prepare(iLocalDb, TDbQuery(sqlText));
		User::LeaveIfError(err);
	
		err=view.EvaluateAll();
		User::LeaveIfError(err);

		if (view.CountL()==0)return -2;
		view.FirstL();
		view.AtRow();
		view.GetL();
		aLACId=view.ColInt(1);
		info.iCellId=view.ColInt(2);
		info.iCellName.Copy(view.ColDes(3));
		view.Close();
	}

	sqlText.Format(KSQLQueryLocal,aLACId);
	//ColumnNamesAndSizes();
		
    err = view.Prepare(iLocalDb, TDbQuery(sqlText));
    User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);

	if (view.CountL()==0)return -1;
	view.FirstL();
	view.AtRow();
	view.GetL();
	TUint mnc=view.ColUint32(1);
	info.iMCC=mnc/1000;
	info.iMNC=mnc%1000;
	info.iLAC=view.ColInt32(2);
	info.iLacName.Copy(view.ColDes(3));
	view.Close();
	
	sqlText.Format(KSQLQueryMNC,mnc);
	err = view.Prepare(iLocalDb, TDbQuery(sqlText));
	User::LeaveIfError(err);
	
	err=view.EvaluateAll();
	User::LeaveIfError(err);
	
	if (view.CountL()==0)return -3;
	view.FirstL();
	view.AtRow();
	view.GetL();
	info.iShortName.Copy(view.ColDes(1));
	info.iLongName.Copy(view.ColDes(2));
	view.Close();
	return 0;
}
