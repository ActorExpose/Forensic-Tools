/*
* ============================================================================
*  Name     : CLocatiqContainer2 from LocatiqContainer2.cpp
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include <eikedwin.h> //CEikEdwin
#include <barsread.h>  // for resource reader
#include <locatieq.rsg>
#include "LocatiqContainer2.h"

#define EDWIN_POS           TPoint(10, 25)

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqContainer2::ConstructL(const TRect& aRect)
// EPOC two phased constructor
// ---------------------------------------------------------
//
void CLocatiqContainer2::ConstructL(const TRect& aRect)
    {
    CreateWindowL();

    TResourceReader reader;
    iCoeEnv->CreateResourceReaderLC(reader, R_AKNEXEDITOR_VIEW1_EDWIN);
    iText = new (ELeave) CEikEdwin;
    iText->SetContainerWindowL(*this);
    iText->ConstructFromResourceL(reader);
	CleanupStack::PopAndDestroy();  // Resource reader
	iText->SetAknEditorAllowedInputModes(EAknEditorAllInputModes);
	iText->SetAknEditorInputMode(EAknEditorTextInputMode);
    iText->SetExtent(EDWIN_POS, iText->MinimumSize());
	//iText->SetTextL(_("Test doang"));
    SetRect(aRect);
    ActivateL();
	iEdit=EFalse;
    }

// Destructor
CLocatiqContainer2::~CLocatiqContainer2()
    {
    delete iText;
    }

// ---------------------------------------------------------
// CLocatiqContainer2::SizeChanged()
// Called by framework when the view size is changed
// ---------------------------------------------------------
//
void CLocatiqContainer2::SizeChanged()
    {
		iText->SetRect( Rect() );
    }

// ---------------------------------------------------------
// CLocatiqContainer2::CountComponentControls() const
// ---------------------------------------------------------
//
TInt CLocatiqContainer2::CountComponentControls() const
    {
    return 1; // return nbr of controls inside this container
    }

// ---------------------------------------------------------
// CLocatiqContainer2::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* CLocatiqContainer2::ComponentControl(TInt aIndex) const
    {
    switch ( aIndex )
        {
        case 0:
            return iText;
        default:
            return NULL;
        }
    }

// ---------------------------------------------------------
// CLocatiqContainer2::Draw(const TRect& aRect) const
// ---------------------------------------------------------
//
void CLocatiqContainer2::Draw(const TRect& aRect) const
    {
    CWindowGc& gc = SystemGc();
    // TODO: Add your drawing code here
    // example code...
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    gc.SetBrushColor(KRgbGray);
    gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);
    }

// ---------------------------------------------------------
// CLocatiqContainer2::HandleControlEventL(
//     CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void CLocatiqContainer2::HandleControlEventL(
    CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
    {
    // TODO: Add your control event handler code here
    }

TKeyResponse CLocatiqContainer2::OfferKeyEventL(
    const TKeyEvent& aKeyEvent,
    TEventCode aType )
    {
	
	if (iEdit){
		return iText->OfferKeyEventL( aKeyEvent, aType );
	} else {
        return EKeyWasNotConsumed;
    }
}
void CLocatiqContainer2::SetEditable(TBool aEdit)
{
	iEdit=aEdit;
	iText->SetFocus(aEdit);
}
void CLocatiqContainer2::SetTextL(const TDesC* aDesc)
{
	iText->SetTextL(aDesc);
}

void CLocatiqContainer2::GetText(TDes& aDes)
{
	iText->GetText(aDes);
}
// End of File  
