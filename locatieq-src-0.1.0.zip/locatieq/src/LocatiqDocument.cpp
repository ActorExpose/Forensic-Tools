/*
* ============================================================================
*  Name     : CLocatiqDocument from LocatiqDocument.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include "LocatiqDocument.h"
#include "LocatiqAppUi.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
CLocatiqDocument::CLocatiqDocument(CEikApplication& aApp)
: CAknDocument(aApp)    
    {
    }

// destructor
CLocatiqDocument::~CLocatiqDocument()
    {
    }

// EPOC default constructor can leave.
void CLocatiqDocument::ConstructL()
    {
    }

// Two-phased constructor.
CLocatiqDocument* CLocatiqDocument::NewL(
        CEikApplication& aApp)     // CLocatiqApp reference
    {
    CLocatiqDocument* self = new (ELeave) CLocatiqDocument( aApp );
    CleanupStack::PushL( self );
    self->ConstructL();
    CleanupStack::Pop();

    return self;
    }
    
// ----------------------------------------------------
// CLocatiqDocument::CreateAppUiL()
// constructs CLocatiqAppUi
// ----------------------------------------------------
//
CEikAppUi* CLocatiqDocument::CreateAppUiL()
    {
    return new (ELeave) CLocatiqAppUi;
    }

// End of File  
