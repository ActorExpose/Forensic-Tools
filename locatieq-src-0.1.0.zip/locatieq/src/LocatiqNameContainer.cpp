/*
* ============================================================================
*  Name     : CLocatiqNameContainer from LocatiqNameContainer.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include <aknlists.h> //CAknSingleLargeStyleListBox
#include <badesca.h>  //CDesCArray
#include "LocatiqNameContainer.h"


// ================= MEMBER FUNCTIONS =======================
// ---------------------------------------------------------
// CLocatiqContainer::ConstructL(const TRect& aRect)
// EPOC two phased constructor
// ---------------------------------------------------------
//
void CLocatiqNameContainer::ConstructL(const TRect& aRect)
    {
    CreateWindowL();

    iList = new (ELeave) CAknSingleStyleListBox;
	iList->SetContainerWindowL(*this);
	// construct listbox
	iList->ConstructL(this, EAknListBoxSelectionList);
	// set container control
	// add scrollbars to listbox
	
	iList->CreateScrollBarFrameL(ETrue);
	iList->ScrollBarFrame()->SetScrollBarVisibilityL(CEikScrollBarFrame::EOn, CEikScrollBarFrame::EAuto );
	iList->ActivateL();
	
    SetRect(aRect);
    ActivateL();
    }

// Destructor
CLocatiqNameContainer::~CLocatiqNameContainer()
    {
    delete iList;
    }

// ---------------------------------------------------------
// CLocatiqContainer::SizeChanged()
// Called by framework when the view size is changed
// ---------------------------------------------------------
//
void CLocatiqNameContainer::SizeChanged()
    {
    // TODO: Add here control resize code etc.
    iList->SetRect( Rect() );
    }

// ---------------------------------------------------------
// CLocatiqContainer::CountComponentControls() const
// ---------------------------------------------------------
//
TInt CLocatiqNameContainer::CountComponentControls() const
    {
    return 1; // return nbr of controls inside this container
    }

// ---------------------------------------------------------
// CLocatiqContainer::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* CLocatiqNameContainer::ComponentControl(TInt aIndex) const
    {
    switch ( aIndex )
        {
        case 0:
            return iList;
        default:
            return NULL;
        }
    }

// ---------------------------------------------------------
// CLocatiqContainer::Draw(const TRect& aRect) const
// ---------------------------------------------------------
//
void CLocatiqNameContainer::Draw(const TRect& aRect) const
    {
    CWindowGc& gc = SystemGc();
    // TODO: Add your drawing code here
    // example code...
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    gc.SetBrushColor(KRgbGray);
    gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);
    }

// ---------------------------------------------------------
// CLocatiqContainer::HandleControlEventL(
//     CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void CLocatiqNameContainer::HandleControlEventL(
    CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
    {
    // TODO: Add your control event handler code here
    }

TKeyResponse CLocatiqNameContainer::OfferKeyEventL(
    const TKeyEvent& aKeyEvent,
    TEventCode aType )
    {
    if ( aType != EEventKey ) // Is not key event?
        {
        return EKeyWasNotConsumed;
        }
	
	switch ( aKeyEvent.iCode )
        {
        case EKeyLeftArrow:
        case EKeyRightArrow:
            return EKeyWasNotConsumed;
        }

	return iList->OfferKeyEventL( aKeyEvent, aType );
    }

void CLocatiqNameContainer::SetLacList(CDesCArray* aList)
{
	iList->Model()->SetOwnershipType(ELbmOwnsItemArray);
	iList->Model()->SetItemTextArray(aList);
	iList->HandleItemAdditionL();
}

void CLocatiqNameContainer::GetSelected(TDes& aName)
{
	TInt index=iList->CurrentItemIndex();
	MDesCArray* textArray = iList->Model()->ItemTextArray();
	CDesCArray* itemList = static_cast<CDesCArray*>(textArray);
	aName.Copy(itemList->MdcaPoint(index).Mid(1));

}
// End of File  
