/*
* ============================================================================
*  Name     : CLocatiqView from LocatiqView.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Implementation notes:
*
*  Version  :
*  Copyright: 
* ============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <AknQueryDialog.h> //CAknTextQueryDialog
#include <aknnotewrappers.h> 
#include  <locatieq.rsg>
#include  "LocatiqCellView.h"
#include  "locatiq.hrh"
#include  "locatiqdb.h"
#include  "LocatiqNameContainer.h" 

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// CLocatiqView::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void CLocatiqCellView::ConstructL(CLocatiqDb *aLocate)
    {
    BaseConstructL( R_LOCATIQ_VIEWNAME );
	iLocate=aLocate;
    }

// ---------------------------------------------------------
// CLocatiqView::~CLocatiqView()
// ?implementation_description
// ---------------------------------------------------------
//
CLocatiqCellView::~CLocatiqCellView()
    {

	
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
	
    delete iContainer;
    }

// ---------------------------------------------------------
// TUid CLocatiqView::Id()
// ?implementation_description
// ---------------------------------------------------------
//
TUid CLocatiqCellView::Id() const
    {
    return KCellViewId;
    }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqCellView::HandleCommandL(TInt aCommand)
    {   
    switch ( aCommand )
        {
		case ElocatiqCmdRename:
			{
				CAknTextQueryDialog* dlg;
				TBuf<KNameLocalMaxLength> textData;
				iContainer->GetSelected(textData);
				dlg = new(ELeave)CAknTextQueryDialog(textData, CAknQueryDialog::ENoTone );
				dlg->SetMaxLength(KNameLocalMaxLength);
				TBool answer( dlg->ExecuteLD( R_LOCATIQ_DATA_QUERY) );
				if (answer){
					TInt id=iLocate->GetCellIdL(textData);
					if (id==-1){
						TBuf<KNameLocalMaxLength> buf;
						iContainer->GetSelected(buf);
						id=iLocate->GetCellIdL(buf);
						iLocate->UpdateCellName(textData,id);
						CDesCArray* arr=iLocate->GetCellsL();
						iContainer->SetLacList(arr);
					} else {
						//TODO name already exist
					}
				}
			}	
			break;
		case ElocatiqCmdDetail:
			{
				TBuf<KNameLocalMaxLength> buf;
				iContainer->GetSelected(buf);
				TInt id=iLocate->GetCellIdL(buf);
				TNetworkInfo ni;
				iLocate->GetNetworkInfo(ni,-1,id);
				
				TBuf<128> msg(ni.iCellName);
				msg.Append(_L(":"));
				msg.Append(ni.iLacName);
				msg.AppendFormat(_L("\nCellId: %d"),ni.iCellId);
				msg.AppendFormat(_L("\nLAC: %d\n"),ni.iLAC);
				msg.Append(ni.iShortName);
				CAknNoteDialog* dlg = new( ELeave ) CAknNoteDialog( 
					CAknNoteDialog::ENoTone, CAknNoteDialog::ENoTimeout);
				dlg->PrepareLC( R_SELECT_MESSAGE_NOTE );
				dlg->SetTextPluralityL( EFalse );
				dlg->SetTextL( msg );
				dlg->RunLD();
			}
			break;
		case ElocatiqCmdRefresh:
		case ElocatiqCmdDelete:
        default:
            {
            AppUi()->HandleCommandL( aCommand );
            break;
            }
        }
    }

// ---------------------------------------------------------
// CLocatiqView::HandleClientRectChange()
// ---------------------------------------------------------
//
void CLocatiqCellView::HandleClientRectChange()
    {
    if ( iContainer )
        {
        iContainer->SetRect( ClientRect() );
        }
    }

// ---------------------------------------------------------
// CLocatiqView::DoActivateL(...)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqCellView::DoActivateL(
   const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
   const TDesC8& /*aCustomMessage*/)
    {
    if (!iContainer)
        {
        iContainer = new (ELeave) CLocatiqNameContainer;
        iContainer->SetMopParent(this);
        iContainer->ConstructL( ClientRect() );
				AppUi()->AddToStackL( *this, iContainer );
				CDesCArray* arr=iLocate->GetCellsL();
				iContainer->SetLacList(arr);
        } 
   }

// ---------------------------------------------------------
// CLocatiqView::HandleCommandL(TInt aCommand)
// ?implementation_description
// ---------------------------------------------------------
//
void CLocatiqCellView::DoDeactivate()
    {
    if ( iContainer )
        {
        AppUi()->RemoveFromViewStack( *this, iContainer );
        }
    
    delete iContainer;
    iContainer = NULL;
    }

// End of File

