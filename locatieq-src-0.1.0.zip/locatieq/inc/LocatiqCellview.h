/*
* ============================================================================
*  Name     : CLocatiqCellView from LocatiqNameView.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Declares view for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef LOCATIQCELLVIEW_H
#define LOCATIQCELLVIEW_H

// INCLUDES
#include <aknview.h>

// CONSTANTS
// UID of view
const TUid KCellViewId = {4};

// FORWARD DECLARATIONS
class CLocatiqNameContainer;
class CLocatiqDb;

// CLASS DECLARATION

/**
*  CLocatiqView view class.
* 
*/
class CLocatiqCellView : public CAknView
    {
    public: // Constructors and destructor

        /**
        * EPOC default constructor.
        */
        void ConstructL(CLocatiqDb *aLocate);

        /**
        * Destructor.
        */
        ~CLocatiqCellView();

    public: // Functions from base classes
        
        /**
        * From ?base_class ?member_description
        */
        TUid Id() const;

        /**
        * From ?base_class ?member_description
        */
        void HandleCommandL(TInt aCommand);

        /**
        * From ?base_class ?member_description
        */
        void HandleClientRectChange();

	public: //New
		

    private:

        /**
        * From AknView, ?member_description
        */
        void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
            const TDesC8& aCustomMessage);

        /**
        * From AknView, ?member_description
        */
        void DoDeactivate();

    private: // Data
        CLocatiqNameContainer* iContainer;
		CLocatiqDb* iLocate;	
    };

#endif

// End of File
