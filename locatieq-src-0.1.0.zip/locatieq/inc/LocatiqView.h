/*
* ============================================================================
*  Name     : CLocatiqView from LocatiqView.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Declares view for application. view of Info (show the info network)
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef LOCATIQVIEW_H
#define LOCATIQVIEW_H

// INCLUDES
#include <aknview.h>

// CONSTANTS
// UID of view
const TUid KViewId = {1};

// FORWARD DECLARATIONS
class CLocatiqContainer;
class CLocatiqDb;

// CLASS DECLARATION

/**
*  CLocatiqView view class.
* 
*/
class CLocatiqView : public CAknView
    {
    public: // Constructors and destructor

        /**
        * EPOC default constructor.
        */
        void ConstructL(CLocatiqDb *aLocate);

        /**
        * Destructor.
        */
        ~CLocatiqView();

    public: // Functions from base classes
        
        /**
        * From ?base_class ?member_description
        */
        TUid Id() const;

        /**
        * From ?base_class ?member_description
        */
        void HandleCommandL(TInt aCommand);

        /**
        * From ?base_class ?member_description
        */
        void HandleClientRectChange();

	public: //New
		void GetLocation();

    private:

        /**
        * From AknView, ?member_description
        */
        void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
            const TDesC8& aCustomMessage);

        /**
        * From AknView, ?member_description
        */
        void DoDeactivate();

    private: // Data
        CLocatiqContainer* iContainer;
		CLocatiqDb* iLocate;	
    };

#endif

// End of File
