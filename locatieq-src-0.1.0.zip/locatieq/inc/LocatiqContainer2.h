/*
* ============================================================================
*  Name     : CLocatiqContainer2 from LocatiqContainer2.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Declares container control for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef LOCATIQCONTAINER2_H
#define LOCATIQCONTAINER2_H

// INCLUDES
#include <coecntrl.h>
 
// FORWARD DECLARATIONS
class CEikEdwin;

// CLASS DECLARATION

/**
*  CLocatiqContainer2  container control class.
*  
*/
class CLocatiqContainer2 : public CCoeControl, MCoeControlObserver
    {
    public: // Constructors and destructor
        
        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL(const TRect& aRect);

        /**
        * Destructor.
        */
        ~CLocatiqContainer2();

    public: // New functions
		void SetTextL(const TDesC* aDesc);
		void GetText(TDes& aDes);
		void SetEditable(TBool aEdit);
    public: // Functions from base classes
		TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType );
    private: // Functions from base classes

       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;

       /**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

       /**
        * From ?base_class ?member_description
        */
        // event handling section
        // e.g Listbox events
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
        
    private: //data
        
        CEikEdwin* iText;          // example label
		TBool  iEdit;
    };

#endif

// End of File
