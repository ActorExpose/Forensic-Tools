/*
* ============================================================================
*  Name     : CLocatiqApp from LocatiqApp.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Declares main application class.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef LOCATIQAPP_H
#define LOCATIQAPP_H

// INCLUDES
#include <aknapp.h>

// CONSTANTS
// UID of the application
const TUid KUidlocatiq = { 0x0EA379C2 };

// CLASS DECLARATION

/**
* CLocatiqApp application class.
* Provides factory to create concrete document object.
* 
*/
class CLocatiqApp : public CAknApplication
    {
    
    public: // Functions from base classes
    private:

        /**
        * From CApaApplication, creates CLocatiqDocument document object.
        * @return A pointer to the created document object.
        */
        CApaDocument* CreateDocumentL();
        
        /**
        * From CApaApplication, returns application's UID (KUidlocatiq).
        * @return The value of KUidlocatiq.
        */
        TUid AppDllUid() const;
    };

#endif

// End of File

