/*
* ============================================================================
*  Name     : CLocatiqAppUi from LocatiqDb.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Database of location engine of LocatieQ
*  Version  :
*  Copyright: 
* ============================================================================
*/
#ifndef LOCATIQDB_H
#define LOCATIQDB_H
// INCLUDES
#include <s32file.h> //CFileStorer
#include  <etel.h>
#include  <etelbgsm.h>
#include <d32dbms.h>    // RDbStoreDatabase
#include <f32file.h>    // RFs
#include <badesca.h>    // CDesCArrayFlat (cannot be forward declarated)


const int KNameLocalMaxLength = 30;
const int KDescriptionMaxLength = 128;
class TNetworkInfo
{
public:
	TUint iMCC;
	TUint iMNC;
	TUint iLAC;
	TUint iCellId;
	TBuf<MBasicGsmPhoneNetwork::KShortNetworkNameSize> iShortName;
	TBuf<MBasicGsmPhoneNetwork::KLongNetworkNameSize> iLongName;
	TBuf<KNameLocalMaxLength> iLacName;
	TBuf<KNameLocalMaxLength> iCellName;
};

class CLocatiqDb: public CBase
{
public:
	
	static CLocatiqDb* NewL();
	CLocatiqDb();
	~CLocatiqDb();
	void ConstructL();

public: //New
	TInt OpenDbL(const TFileName& aExistingFile);
	TInt Close();
	TInt CreateDbL(const TFileName& aNewFile);
	TInt RemoveDbL(const TFileName& aExistingFile);
	TBool IsOpen() const;
	CDesCArrayFlat* GetLocalsL(TInt32 aMnc=-1);
	CDesCArrayFlat* GetCellsL(TInt32 aLacId=-1);
	CDesCArrayFlat* GetCellsL(const TDesC& aLocal);
	TInt UpdateLocalName(const TDesC& aName,TInt32 aLac=-1);
	TInt UpdateCellName(const TDesC& aName,TUint32 aId=-1);
	TInt UpdateCellDescriptioL(const TDesC& aDesc,TInt32 aId=-1);
	TInt32 GetLACIdL(TInt32 aLac=-1, TInt32 aMnc=-1);
	TInt32 GetLACIdL(const TDesC& aName);
	TInt32 GetCellIdL(TInt32 aCellId=-1, TInt32 aIdLac=-1);
	TInt32 GetCellIdL(const TDesC& aName);
	TInt GetCellDescL(TDes& aDes,TInt32 aId=-1);
	TInt GetNetworkInfo(TNetworkInfo& info, TInt32 aLacID,TInt32 aCellID=-1);
	TBool isMNCExistL(TInt32 aMnc=-1);
	CDesCArrayFlat* ColumnNamesAndSizes();

	void RefreshLocationL();
	const TDesC& LocaleNameL();
	
	const TUint MCC(){return iNetworkInfo.iMCC;};
	const TUint MNC(){return iNetworkInfo.iMNC;};
	const TUint LAC(){return iNetworkInfo.iLAC;};
	const TUint CellId(){return iNetworkInfo.iCellId;};
	const TDesC& ShortName(){return iNetworkInfo.iShortName;};
	const TDesC& LongName(){return iNetworkInfo.iLongName;};

public:
	CDesCArrayFlat* GetAllLocaleL();
	//void GetNetworkInfoByNameL(const CDesC& aName,TNetworkInfo& aNetworkInfo);


private: //Database module
	void CreateNetworkTableL();
	void CreateLocalTableL();
	void CreateCellsTableL();
	void CreateNetworkIndexL();
	void CreateLocalIndexL();
	void CreateCellsIndexL();
	void DropTableL(const TDesC& aTable);
	TInt AddLocalL();

private:
	RBasicGsmPhone iPhone;
	RTelServer iServer;	
	
	TNetworkInfo iNetworkInfo;
	TInt32 iCurrentIdCell;
	TInt32 iCurrentIdLac;
	//Db
	RFs              iFsSession;  /* For use of iFileStore                   */
    RDbStoreDatabase iLocalDb;/* For database operations                 */
    CFileStore*      iFileStore;  /* For creating and opening database files */
    TBool            iOpen;       /* Flag indicating iBookstoreDb open status*/
	TBool			 iIsLacChange;
#ifdef __WINS__
	TInt iCellId;
#endif
};

#endif