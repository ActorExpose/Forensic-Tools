/*
* ============================================================================
*  Name     : CLocatiqContainer from LocatiqContainer.h
*  Part of  : locatiq
*  Created  : 11/26/2005 by amadarum
*  Description:
*     Declares container control for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef LOCATIQCONTAINER_H
#define LOCATIQCONTAINER_H

// INCLUDES
#include <coecntrl.h>
   
// FORWARD DECLARATIONS
class CEikTextListBox;        // for example labels

// CLASS DECLARATION

/**
*  CLocatiqContainer  container control class.
*  
*/
class CLocatiqContainer : public CCoeControl, MCoeControlObserver
    {
    public: // Constructors and destructor
        
        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL(const TRect& aRect);

        /**
        * Destructor.
        */
        ~CLocatiqContainer();

    public: // New functions
		void SetNetworkInfo(TUint aMCC, TUint aMNC,TUint aLAC, TUint aCID,const TDesC& aShorName, const TDesC& aLongName);

    public: // Functions from base classes

    private: // Functions from base classes
		TKeyResponse CLocatiqContainer::OfferKeyEventL(
			const TKeyEvent& aKeyEvent,
			TEventCode aType );
       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;

       /**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

       /**
        * From ?base_class ?member_description
        */
        // event handling section
        // e.g Listbox events
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
        
    private: //data
        
        CEikTextListBox * iList;

    };

#endif

// End of File
