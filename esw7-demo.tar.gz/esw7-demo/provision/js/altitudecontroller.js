function AltitudeController(name) {
	this._name = name;
	this._controlElement = document.getElementById(name);
	this.init();
}
AltitudeController.prototype = {
	altitudeInfo: new Altitude(),
	
	// UI logic
	_name: null,
	_controlElement: null,
	_altDiv: null,
	_altCheck: null,
	_altField: null,
	_altUnit: null,
	_altErrDiv: null,
	_altErrCheck: null,
	_altErrField: null,
	
	init: function() {
		var controller = this;
		
		{
			// Construct and add altitude div
			this._altDiv = document.createElement("div");
			this._altCheck = document.createElement("input");
			var altLabel = document.createElement("label");
			this._altField = document.createElement("input");
			this._altUnit = document.createElement("select");
			
			// Assembly
			this._altDiv.style.margin = ".5ex";
			this._altCheck.type = "checkbox";
			this._altCheck.checked = true;
			this._altCheck.id = this._name + ".altCheck";
			altLabel.htmlFor = this._name + ".altCheck";
			altLabel.innerHTML = "Altitude: ";
			this._altField.type = "text";
			var opt;
			opt = document.createElement("option");
			opt.value = Altitude.Units.Meters;
			opt.innerHTML = "meters";
			this._altUnit.appendChild(opt);
			opt = document.createElement("option");
			opt.value = Altitude.Units.Floors;
			opt.innerHTML = "floors";
			this._altUnit.appendChild(opt);
			
			// Behavior
			var update = function() { controller.update(); };
			this._altCheck.onchange = update;
			this._altField.onchange = update;
			this._altUnit.onchange = update;
			
			// Glue!
			this._altDiv.appendChild(this._altCheck);
			this._altDiv.appendChild(altLabel);
			this._altDiv.appendChild(this._altField);
			this._altDiv.appendChild(this._altUnit);
			this._controlElement.appendChild(this._altDiv);
		}
		
		{
			// Construct and add altitude error div
			this._altErrDiv = document.createElement("div");
			this._altErrCheck = document.createElement("input");
			var altErrLabel = document.createElement("label");
			this._altErrField = document.createElement("input");
			
			// Assembly
			this._altErrDiv.style.margin = ".5ex";
			this._altErrCheck.type = "checkbox";
			this._altErrCheck.id = this._name + ".altCheck";
			altErrLabel.htmlFor = this._name + ".altCheck";
			altErrLabel.innerHTML = "Altitude Error: ";
			this._altErrField.type = "text";
			
			// Behavior
			var update = function() { controller.update(); };
			this._altErrCheck.onchange = update;
			this._altErrField.onchange = update;
			
			// Glue!
			this._altErrDiv.appendChild(this._altErrCheck);
			this._altErrDiv.appendChild(altErrLabel);
			this._altErrDiv.appendChild(this._altErrField);
			this._controlElement.appendChild(this._altErrDiv);
		}
		
		this.update();
	},
	
	// Application logic
	update: function() {
		// Enable / disable error window
		var enabled = this._altCheck.checked;
		var errEnabled = this._altErrCheck.checked;
		if (enabled) {
			// Enable the base fields
			this._altField.disabled = "";
			this._altUnit.disabled = "";
			
			// Show the altErr div
			this._altErrDiv.style.display = "";
			
			// Enable the error field if necessary
			if (errEnabled) {
				this._altErrField.disabled = "";
			} else {
				this._altErrField.disabled = "true";
			}
			
			// Package up an altitude information object and ship it
			if (enabled) {
				this.altitudeInfo = new Altitude();
				this.altitudeInfo.altitude = parseFloat(this._altField.value);
				this.altitudeInfo.unit = this._altUnit.value;
				this.altitudeInfo.hasError = errEnabled;
				if (errEnabled) {
					this.altitudeInfo.altitudeError = parseFloat(this._altErrField.value);
				} 
				
				// Check that everything is valid and notify
				if ((!isNaN(this.altitudeInfo.altitude) &&
				    ((!this.altitudeInfo.hasError)||(!isNaN(this.altitudeInfo.altitudeError)))))
				{
					this.notifyListeners();
				}
			} else {
				this.clearListeners();
			}
					
		} else {
			// Disable the base fields
			this._altField.disabled = "true";
			this._altUnit.disabled = "true";
			
			// Hide the altErr div
			this._altErrDiv.style.display = "none";
		}
	},
	
	// Listener management functions
	listeners: [],
	
	addListener: function(obj) {
		if (obj != null) {
			this.listeners.push(obj);
			return (this.listeners.length-1);
		}
	},
	
	removeListener: function(ix) {
		delete this.listeners[ix];
	},
	
	notifyListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].notify(this.altitudeInfo); } 
	},
	
	clearListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].clear(); } 
	}
};
