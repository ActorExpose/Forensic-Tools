function Altitude() {}
Altitude.Units = {
	Unknown: 0,
	Meters: 1,
	Floors: 2
}
Altitude.prototype = {
	altitude: 0,
	unit: 0,
	hasError: false,
	altitudeError: 0
};

//// GEODETIC INFO
function Geodetic() {}
Geodetic.prototype = {
	shape: null,
	altitudeInfo: null
};
