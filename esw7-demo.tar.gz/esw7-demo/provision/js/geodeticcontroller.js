function GeodeticController(name) {
	this._name = name;
	this._controlElement = document.getElementById(name);
	this.init();
}
GeodeticController.prototype = {
	_name: null,
	_controlElement: null,
	
	geoInfo: new Geodetic(),
	mapController: null,
	altController: null,	
	
	// UI/Applciation logic
	_mapDiv: null,
	_altDiv: null,
	
	_mapListener: null,
	_altListener: null,
	
	init: function() {
		{
			// Create sub-controls for mapping and altitude
			this._mapDiv = document.createElement("div");
			this._mapDiv.id = this._name + ".map";
			
			this._altDiv = document.createElement("div");
			this._altDiv.id = this._name + ".alt";
			
			this._controlElement.appendChild(this._mapDiv);
			this._controlElement.appendChild(this._altDiv);
			
			this.mapController = new MapController(this._mapDiv.id);
			this.altController = new AltitudeController(this._altDiv.id);
		}
		
		{
			// Set up listeners that flow into a master listener management
			// Notify if (have_shape)&&(altitude_changed)
			var geoController = this;
			this._mapListener = {
				notify: function(loc) { 
					geoController.geoInfo.shape = loc;
					geoController.notifyListeners();
				},
				clear: function() {
					geoController.geoInfo.shape = null;
					geoController.clearListeners();
				}
			};
			this._altListener = {
				notify: function(altInfo) { 
					geoController.geoInfo.altitudeInfo = altInfo;
					if (geoController.geoInfo.shape) {
						geoController.notifyListeners();
					}
				},
				clear: function() {
					geoController.geoInfo.altitudeInfo = null;
					if (geoController.geoInfo.shape) {
						geoController.notifyListeners();
					}
				}
			};
			
			this.mapController.addListener(this._mapListener);
			this.altController.addListener(this._altListener);
		}
	},
	
	update: function() {
		if (this.geoInfo.shape != null) { 
			this.notifyListeners(); 
		} else { 
			this.clearListeners(); 
		}
	},
	
	// Listener management functions
	listeners: [],
	
	addListener: function(obj) {
		if (obj != null) {
			this.listeners.push(obj);
			return (this.listeners.length-1);
		}
	},
	
	removeListener: function(ix) {
		delete this.listeners[ix];
	},
	
	notifyListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].notify(this.geoInfo); } 
	},
	
	clearListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].clear(); } 
	}
};
