function Shape(shapeType) {
	this.type = shapeType;
	this.points = [];
}
Shape.Types = {
	"Point": 0,
	"Circle": 1,
	"Rectangle": 2,
	"Polygon": 3,
};
Shape.createInstance = function(type) {
	switch (type) {
		case (Shape.Types.Point): return new Point();
		case (Shape.Types.Circle): return new Circle();
		case (Shape.Types.Rectangle): return new Rectangle(); // Deprecated
		case (Shape.Types.Polygon): return new Polygon();
	}
}
Shape.overlayColor = "#9999FF";
Shape.overlayOpacity = .5;
Shape.overlayWeight = 1;
Shape.prototype = {
	type: null,		// Kind of shape
	points: [],		// Points constituting the shape (point, center/edge, corners)
	
	addPoint: function(latlng) {
		this.points.push(latlng);
	},

	toString: function() {},

	toGMapShape: function() {},

    getCentroid: function() {},

    getUncertainty: function() {}
};
Shape.fromGML = function(gmlString) {
	var parser=new DOMParser();
    var gmlDoc=parser.parseFromString(gmlString,"text/xml");
	var shapeNode = gmlDoc.documentElement;
	var shapeType = shapeNode.localName;
	
	if ((shapeType == "Point")||(shapeType == "Polygon")) {
		var posElts = shapeNode.getElementsByTagNameNS("http://www.opengis.net/gml","pos");
		if (posElts.length == 0) {
			return null;
		} else {
			var shape
			if (shapeType == "Point")
				shape = new Point();
			else 
				shape = new Polygon();
			
			shape.points = [];
			for (var i=0; i<posElts.length; ++i) {
				var pos = posElts.item(i).firstChild.nodeValue;
				var latlng = pos.split(/[ ]+/);
				var lat = latlng[0];
				var lng = latlng[1];
				shape.points[i] = new GLatLng(lat,lng);
			}
			
			return shape;
		}
	} else if (shapeType == "Circle") {
		var posElts = shapeNode.getElementsByTagNameNS("http://www.opengis.net/gml","pos");
		var radElts = shapeNode.getElementsByTagNameNS("http://www.opengis.net/pidflo/1.0", "radius");
		
		if ((posElts.length == 0)||(radElts.length == 0)) {
			return null;
		} else {
			var shape = new Circle();
			var pos = posElts.item(0).firstChild.nodeValue;
			var latlng = pos.split(/[ ]+/);
			var lat = latlng[0];
			var lng = latlng[1];
			shape.points[0] = new GLatLng(lat,lng);
			shape.radius = parseFloat(radElts.item(0).firstChild.nodeValue);
			return shape;
		}
	} 
}
Shape.prototype.quickMap = function(name) {
	var gmap = new GMap(document.getElementById(name));
	gmap.setUIToDefault();
		
	var shape = this.toGMapShape();
	gmap.setCenter(this.getCentroid());
	if (this.type == Shape.Types.Point) {
		gmap.setZoom(8);
	} else {
		gmap.setZoom( gmap.getBoundsZoomLevel(shape.getBounds()) );
	}
	gmap.addOverlay(shape);	
    return gmap;
}



function Point() {
	this.type = Shape.Types.Point;
	this.points = [];
	return this;
}
Point.prototype = new Shape();
Point.prototype.toString = function() {
	return "Point( "+ this.points[0].lat() +", "+ this.points[0].lng() + ")";
};
Point.prototype.toGMapShape = function() {
	return new GMarker(this.points[0]);
}
Point.prototype.toGeoShape = function() {
	if (this.points.length < 1) return null;

	var ret = "";
	ret += "<gml:Point srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
	ret += "    xmlns:gml=\"http://www.opengis.net/gml\" >\n";
	ret += "  <gml:pos>"+ this.points[0].lat() +" "+ this.points[0].lng() +"</gml:pos>";
	ret += "</gml:Point>";
	return ret;
};
Point.prototype.getCentroid = function() {
    if (this.points.length < 1) return;
    return this.points[0];
}
Point.prototype.getUncertainty = function() {
    return 0;
}
Point.prototype.getLatUncertainty = function() {
    return 0;
};
Point.prototype.getLngUncertainty = function() {
    return 0;
};

function Circle() {
	this.type = Shape.Types.Circle;
	this.points = [];
    this.radius = null;
	return this;
}
Circle.prototype = new Shape();
Circle.prototype.radius = null;
Circle.prototype.addPoint = function(latlng) {
    if (this.points.length == 0)
		this.points.push(latlng);
    else {
        this.radius = this.points[0].distanceFrom(latlng);
    }
};
Circle.prototype.toString = function() {
	var ret = "Circle( ";	
	for (var i=0; i<this.points.length; ++i) {
		ret += "(" + this.points[i].lat() + ", " + this.points[i].lng() + ") "; 
	}
	ret += ") ";
    ret += " radius="+this.radius;
	return ret;
};
Circle.prototype.toGMapShape = function() {
	if ((this.points.length == 1)&&(!this.radius)) {
		return new GMapPoint(this.points[0]);
	} else if ((this.points.length == 1)&&(this.radius)) {
		return new GMapEllipse(this.points[0], this.radius)
	}
};
Circle.prototype.toGeoShape = function() {
	if ((this.points.length < 1)||(!this.radius)) return null;

	var ret = "";
	ret += "<gs:Circle srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
	ret += "    xmlns:gs=\"http://www.opengis.net/pidflo/1.0\" \n";
	ret += "    xmlns:gml=\"http://www.opengis.net/gml\" >\n";
	ret += "  <gml:pos>"+ this.points[0].lat() +" "+ this.points[0].lng() +"</gml:pos>\n";
	ret += "  <gs:radius uom=\"urn:ogc:def:uom:EPSG::9001\">"+ this.radius +"</gs:radius>\n";
	ret += "</gs:Circle>";
	return ret;
};
Circle.prototype.getCentroid = function() {
    if (this.points.length < 1) return;
    return this.points[0];
};
Circle.prototype.getUncertainty = function() {
    return this.radius;
};
Circle.prototype.getLatUncertainty = function() {
    if (this.points.length < 2) return 0;
    // XXX: Use the ratio of distances in Lat/Long space to real distances
    //      to approximate the distance in degrees (this must be wrong)
    return Math.sqrt(
           Math.pow(this.points[0].lat() - this.points[1].lat(), 2) + 
           Math.pow(this.points[0].lng() - this.points[1].lat(), 2) );
};
Circle.prototype.getLngUncertainty = function() {
    return this.getLatUncertainty();
};

function Polygon() {
	this.type = Shape.Types.Polygon;
	this.points = [];
}
Polygon.prototype = new Shape();
Polygon.prototype.finish = function() {
	this.points[this.points.length] = this.points[0];
};
Polygon.prototype.toString = function() {
	var ret = "Polygon( ";	
	for (ix in this.points) {
		ret += "(" + this.points[ix].lat() + ", " + this.points[ix].lng() + ") "; 
	}
	ret += ")"
	return ret;
};
Polygon.prototype.toGMapShape = function() {
    return new GPolygon(
		this.points,
		Shape.overlayColor,
		Shape.overlayWeight,
		Shape.overlayOpacity,
		Shape.overlayColor,
		Shape.overlayOpacity,
        {clickable: false}
	);
};
Polygon.prototype.toGeoShape = function() {
	if (this.points.length < 2) return null;

	var ret = "";
	ret += "<gml:Polygon srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
	ret += "    xmlns:gml=\"http://www.opengis.net/gml\" >\n";
	ret += "  <gml:exterior>\n";
	ret += "    <gml:LinearRing>\n";
	for (var i=0; i<this.points.length; ++i) {
		ret += "      <gml:pos>"+ this.points[i].lat() +" "+ this.points[i].lng() +"</gml:pos>\n";
	}
	ret += "    </gml:LinearRing>\n";
	ret += "  </gml:exterior>\n";
	ret += "</gml:Polygon>";
	return ret;
};
Polygon.prototype.getCentroid = function() {
    // Following algorithm from http://en.wikipedia.org/wiki/Centroid#Centroid_of_polygon
    if (this.points.length < 4) return; // have to have at least a triangle (with closure)
    var area = 0; 
    var centroid = [0, 0];
    for (var i=0; i<this.points.length-1; ++i) {
        var base = (this.points[i].lat() * this.points[i+1].lng() -
                    this.points[i+1].lat() * this.points[i].lng());
        centroid[0] += base * (this.points[i].lat() + this.points[i+1].lat());
        centroid[1] += base * (this.points[i].lng() + this.points[i+1].lng());
        area += base;
    }
    area /= 2;
    centroid[0] /= 6*area;
    centroid[1] /= 6*area;
    return new GLatLng(centroid[0], centroid[1]);
};
Polygon.prototype.getUncertainty = function() {
    // Uncertainty = max distance from centroid of a vertex
    if (this.points.length < 4) return; // have to have at least a triangle (with closure)
    var centroid = this.getCentroid();
    var uncertainty = 0;
    for (var i=0; i<this.points.length-1; ++i) {
        if (centroid.distanceFrom(this.points[i]) > uncertainty) {
            uncertainty = centroid.distanceFrom(this.points[i]);
        }
    }
    return uncertainty;
};
Polygon.prototype.getLatUncertainty = function() {
    var clat = this.getCentroid().lat();
    var uncertainty = 0;
    for (var i=0; i<this.points.length-1; ++i) {
        if (Math.abs(this.points[i].lat() - clat) > uncertainty) {
            uncertainty = Math.abs(this.points[i].lat() - clat);
        }
    }
    return uncertainty;
};
Polygon.prototype.getLngUncertainty = function() {
    var clng = this.getCentroid().lng();
    var uncertainty = 0;
    for (var i=0; i<this.points.length-1; ++i) {
        if (Math.abs(this.points[i].lng() - clng) > uncertainty) {
            uncertainty = Math.abs(this.points[i].lng() - clng);
        }
    }
    return uncertainty;
};

function Rectangle() {
	this.type = Shape.Types.Rectangle;
	this.points = [];
}
Rectangle.prototype = new Polygon();
Rectangle.prototype.toString = function() {
	var ret = "Rectangle( ";	
	for (var i=0; i<this.points.length; ++i) {
		ret += "(" + this.points[i].lat() + ", " + this.points[i].lng() + ") "; 
	}
	ret += ")"
	return ret;
};
Rectangle.prototype.addPoint = function(latlng) {
    if (this.points.length == 0)
		this.points.push(latlng);
    else {
        var point0 = this.points[0];
        var point1 = latlng;

		var minlat = Math.min(point0.lat(), point1.lat()); 
		var maxlat = Math.max(point0.lat(), point1.lat()); 
		var minlng = Math.min(point0.lng(), point1.lng()); 
		var maxlng = Math.max(point0.lng(), point1.lng()); 

        this.points = [];
        this.points.push(new GLatLng(minlat, minlng));
        this.points.push(new GLatLng(minlat, maxlng));
        this.points.push(new GLatLng(maxlat, maxlng));
        this.points.push(new GLatLng(maxlat, minlng));
        this.points.push(new GLatLng(minlat, minlng));
    }
};

