function LocationController(geoName, civicName) {
	this._geoName = geoName;
	this._civicName = civicName;
	
	this.geoController = new GeodeticController(geoName);
	this.civicController = new CivicController(civicName);
	
	this.init();
}
LocationController.prototype = {
	_geoName: null,
	_civicName: null,
	
	location: new LocationObject(),
	geoController: null,
	civicController: null,
	
	_geoListener: null,
	_civicListener: null,
	
	init: function() {
		// No UI; geo/civic take care of it
		var controller = this;
		this._geoListener = {
			notify: function(loc) { 
				controller.location.geo = loc;
				controller.update();
			},
			clear: function() {
				controller.location.geo = null;
				controller.update();
			}
		};
		
		this._civicListener = {
			notify: function(loc) { 
				controller.location.civic = loc;
				controller.update();
			},
			clear: function() {
				controller.location.civic = null;
				controller.update();
			}
		};
		
		this.geoController.addListener(this._geoListener);
		this.civicController.addListener(this._civicListener);
	},
	
	update: function() {
		if ((this.location.geo && this.location.geo.shape) || this.location.civic) {
			this.notifyListeners();
		} else {
			this.clearListeners();
		}
	},
	
	// Listener management functions
	listeners: [],
	
	addListener: function(obj) {
		if (obj != null) {
			this.listeners.push(obj);
			return (this.listeners.length-1);
		}
	},
	
	removeListener: function(ix) {
		delete this.listeners[ix];
	},
	
	notifyListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].notify(this.location); } 
	},
	
	clearListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].clear(); } 
	}
};
