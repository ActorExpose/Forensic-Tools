function selectFromMap(labelObject) {
	var select = document.createElement("select");
	
	for (name in labelObject) {
		var option = document.createElement("option");
		option.value = name;
		option.innerHTML = labelObject[name];
		select.appendChild(option);
	}
	
	return select;
}




function CivicController(name) {
	this._name = name;
	this._controlElement = document.getElementById(name);
	this.init();
}
CivicController.prototype = {
	_name: null,
	_controlElement: null,
	
	civic: null,
	
	// UI Logic
	_masterDiv: null,
	_whatSelect: null,
	_countrySelect: null,
	_addElementButton: null,
	_removeElementButton: null,
	_elementDiv: null,
	_elements: [],
	
	init: function() {
		var controller = this;
		var updateFn = function() { controller.update() };
		var clearFn = function() { controller.clear() };
		var tempElement; 
		
		{
			// Add the master div
			this._masterDiv = document.createElement("div");
			this._masterDiv.style.overflow = "auto";
			this._masterDiv.style.height = "20em";
		}
		
		{
			// Add the 'what' select
			tempElement = document.createElement("h2");
			tempElement.innerHTML = "1. Specify what's being located";
			
			this._whatSelect = selectFromMap(Civic.What); 
			this._whatSelect.onchange = updateFn;
			
			this._masterDiv.appendChild(tempElement);
			this._masterDiv.appendChild(this._whatSelect);
		}
		
		{
			// Add the 'country' select
			tempElement = document.createElement("h2");
			tempElement.innerHTML = "2. Specify a country";
			
			this._countrySelect = selectFromMap(Civic.Countries); 
			this._countrySelect.onchange = updateFn;
			
			this._masterDiv.appendChild(tempElement);
			this._masterDiv.appendChild(this._countrySelect);
		}
		
		{
			// Add the 'CAtype' zone
			tempElement = document.createElement("h2");
			tempElement.innerHTML = "3. Add additional attributes";
			this._masterDiv.appendChild	(tempElement);
			
			// Add the add/remove buttons
			tempElement = document.createElement("div");
			
			this._addElementButton = document.createElement("button");
			this._addElementButton.innerHTML = "+";
			this._addElementButton.onclick = function() { controller.pushElement(); }
			
			this._removeElementButton = document.createElement("button");
			this._removeElementButton.innerHTML = "-";	
			this._removeElementButton.onclick = function() { controller.popElement(); }
			
			tempElement.appendChild(this._addElementButton);
			tempElement.appendChild(this._removeElementButton);
			this._masterDiv.appendChild(tempElement);
			
			// Add the zone for the elements themselves
			this._elementDiv = document.createElement("div");
			this._masterDiv.appendChild(this._elementDiv);
			
		}
		
		{
			// Add the 'clear' button
			tempElement = document.createElement("button");
			tempElement.innerHTML = "Clear all values";
			tempElement.onclick = clearFn;
			tempElement.style.marginTop = "1em";
			
			this._masterDiv.appendChild(tempElement);
		}
		
		this._controlElement.appendChild(this._masterDiv);
	},
	
	pushElement: function() {
		var controller = this;
		var row = document.createElement("div");
		var typeElt = selectFromMap(Civic.CATypes);
		var valueElt = document.createElement("input");
		valueElt.setAttribute.type = "text";
	
		typeElt.onchange = function() { controller.update(); }
		valueElt.onchange = function() { controller.update(); }
		
		row.typeElt = typeElt;
		row.valueElt = valueElt;
		row.appendChild(typeElt);
		row.appendChild(valueElt);
	
		this._elements.push(row);
		this._elementDiv.appendChild(row);
		
		this.update();
	},
	
	popElement: function() {
		var row = this._elements.pop();
		this._elementDiv.removeChild(row);
		this.update();
	},
	
	update: function() {
		if ((this._whatSelect.value == -1)||(this._countrySelect.value == 0))
			return;
			
		this.civic = new Civic();
		this.civic.what = this._whatSelect.value;
		this.civic.setElement("country", this._countrySelect.value);
		for (ix in this._elements) {
			var elt = this._elements[ix];
			if (elt.typeElt.value != -1) {
				var typeName = Civic.CATypes[elt.typeElt.value];
				this.civic.setElement(typeName, elt.valueElt.value);
			}
		}
		this.notifyListeners();
	},
	
	clear: function() {
		this._whatSelect.value = -1;
		this._countrySelect.value = 0;
		
		while (this._elements.length > 0) {
			this.popElement();
		}
		
		this.clearListeners();
	},
	
	// Listener management functions
	listeners: [],
	
	addListener: function(obj) {
		if (obj != null) {
			this.listeners.push(obj);
			return (this.listeners.length-1);
		}
	},
	
	removeListener: function(ix) {
		delete this.listeners[ix];
	},
	
	notifyListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].notify(this.civic); } 
	},
	
	clearListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].clear(); } 
	}
};
