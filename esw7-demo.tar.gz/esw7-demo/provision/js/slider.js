/*

Class to manage a slider:

<div id="exampleSlider-container" class="sliderContainer">
  <div id="exampleSlider-header" class="sliderHeader" onclick="Slide('exampleSlider');">
     DHCP Geodetic Location
  </div>
  <div id="exampleSlider-content" class="sliderContent">
     CONTENT GOES HERE!
  </div>
</div>
*/
function Slider(name) {
	this.name = name;
}

Slider.prototype = {
	// Parameters (size units: px)
	contentHeightMax: 0,	
	contentWidth: "",
	slideIncrement: 30,
	slideInterval: 20,
	
	// State variables
	_headerHeight: 5,
	_contentHeight: 232,
	name: "",
	get headerHeight() { return this._headerHeight; },
	get contentHeight() { return this._contentHeight; },
	set contentHeight(val) { this._contentHeight = val; this.setStyleHeights(); },
	get isOpen() { return this.contentHeight == this.contentHeightMax; },
	
	// Internal state variables
	sliding: false,			// Are we in the process of sliding?
	slideIntervalId: 0,		// Handle to the interval struct for this slider

	// Constituent elements
	container: null,
	header: null,
	content: null,
	
	init: function() {
		// Grab handles to all the right elements
		this.container = document.getElementById(this.name + "-container");
		this.header = document.getElementById(this.name + "-header");
		this.content = document.getElementById(this.name + "-content");
		
		// Set width to the standard size
		if (this.contentWidth == "") {
			this.container.style.width = "95%";
			this.header.style.width = "95%";
			this.content.style.width = "95%";
		} else { 
			this.container.style.width = this.contentWidth;
			this.header.style.width = this.contentWidth;
			this.content.style.width = this.contentWidth;
		}
		
		// Fix positioning
		this.header.style.top = "0";
		this.header.style.left = "0";
		this.content.style.left = "0";
		
		// Auto-detect height settings (in px)
		this._headerHeight = this.header.offsetHeight;
		this.contentHeightMax = this.content.offsetHeight;
		this.contentHeight = this.contentHeightMax;
	
		this.setStyleHeights();
	},
	
	// Make the heights in the style match our internal state
	setStyleHeights: function () {
		this.content.style.height = this.contentHeight + "px";
		this.content.style.top = this.headerHeight + "px";
		this.container.style.height = (this.contentHeight + this.headerHeight)+"px";
	},
	
	// Functions for sliding up and down
	// Master Slide function has to be outside of class for setInterval purposes
	slideUp: function () {
		if (this.contentHeight <= 0) {
			this.sliding = false;
			this.contentHeight = 0;
			this.content.style.display = "none";
			clearInterval(this.sliderIntervalId);
		} else {
			this.contentHeight = this.contentHeight - this.slideIncrement;
			if (this.contentHeight < 0) this.contentHeight = 0;
		}
	},
	
	slideDown: function () {
		if (this.contentHeight >= this.contentHeightMax) {
			this.sliding = false;
			this.contentHeight = this.contentHeightMax;
			clearInterval(this.sliderIntervalId);
		} else {
			var increment = Math.min(this.slideIncrement, this.contentHeightMax - this.contentHeight);
			this.contentHeight = this.contentHeight + increment;
			if (this.contentHeight < 0) this.contentHeight = 0;
		}
	},

	close: function() { 
		this.content.style.display = "none";
		this.contentHeight = 0; 
	},
	open: function() { 
		this.contentHeight = this.contentHeightMax; 
		this.content.style.display = "";
	}
};


var SliderManager = {
	sliders: {},
	
	add: function(name) {
		this.sliders[name] = new Slider(name);
	},
	
	slide: function(name) {
		var slider = this.sliders[name];
	
		if (slider.sliding) return;
		else slider.sliding = true;
	
		if (slider.isOpen) {
			slider.sliderIntervalId = setInterval("SliderManager.sliders[\""+ name +"\"].slideUp()", 
				slider.slideInterval);
		} else {
			slider.content.style.display = "";
			slider.sliderIntervalId = setInterval("SliderManager.sliders[\""+ name +"\"].slideDown()", 
				slider.slideInterval);
		}
	}
};

