/*
LocationObject.prototype = {
    geo: Geodetic {
        shape: Shape,
        altitudeInfo: Altitude
    },
    civic: Civic;
} 
*/

//// CIVIC ADDRESS
//#include <civic.js>

//// 2D GEO SHAPES 
//#include <shapes.js>

//// ALTITUDE INFO
function Altitude() {}
Altitude.Units = {
	Unknown: 0,
	Meters: 1,
	Floors: 2
}
Altitude.prototype = {
	altitude: 0,
	unit: 0,
	hasError: false,
	altitudeError: 0
};

//// GEODETIC INFO
function Geodetic() {}
Geodetic.prototype = {
	shape: null,
	altitudeInfo: null
};

//// LOCATION OBJECT
function LocationObject() {}
LocationObject.prototype = {
	geo: null,		// type Geodetic
	civic: null,	// type Civic
};


