/*
Class hierarchy:

TextEncoder
|-- PidfLoEncoder
|-- W3CEncoder
|-- DhcpEncoder
    |-- Dhcp0Encoder
    |-- Dhcp1Encoder
    |-- DhcpCivicEncoder

Dependencies:
shapes.js
civic.js
dhcp99.js
dhcp123.js

*/

function TextEncoder(name, source, typeNames) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._typeNames = typeNames;
	this._buttons = [];
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source || typeNames) {
		this.init();
	}
}
TextEncoder.prototype = {
	_name: null,
	_typeNames: null,
	_source: null,
	
	locationValue: null,
	textValue: null,
	typeName: null,
	
	_controlElement: null,
	_buttons: null,
	_outputDiv: null,
	_outputField: null,
	
	_activeClass: "active",
	
	init: function() {
		var encoder = this;
		
		{
			// Add the type buttons
			for (ix in this._typeNames) {
				var btn = document.createElement("button");
				btn.innerHTML = this._typeNames[ix];
				btn.style.cssFloat = "left";
				btn.typeName = this._typeNames[ix];
				btn.onclick = function() { 
					encoder.typeName = this.typeName; // this == btn
					encoder.update(); 
				};
				this._buttons[ix] = btn;
				this._controlElement.appendChild(btn);
			}
		}
		
		{
			// Add the output field
			this._outputDiv = document.createElement("div");
			this._outputDiv.setAttribute("class", "encoderOutput");
			this._outputField = document.createElement("pre");
			this._outputDiv.appendChild(this._outputField);
			this._controlElement.appendChild(this._outputDiv);
		}
		
		// Subscribe to the source if provided
		if (this._source) {
			this._source.addListener(this);
		}
		
		// Set the default type name (the first one, if any)
		if (this._typeNames && this._typeNames.length > 0) {
			this.typeName = this._typeNames[0];
		}
		
		this.update();	
	},
	
	update: function() {
		// Color the buttons
		for (ix in this._typeNames) {
			if (this._typeNames[ix] == this.typeName) {
				this._buttons[ix].setAttribute("class", this._activeClass);
			} else {
				this._buttons[ix].setAttribute("class", "");
			}
		}
		
		// Encode the location value according to the active type
		this.encode();
		this._outputField.innerHTML = this.textValue;
	},
	
	encode: function() {
		this.textValue = "Generic encoding :: " + this.typeName 
		this.textValue += "\n" + this.locationValue;
	},
	
	// Listener functions
	notify: function(loc) {
		this.locationValue = loc;
		this.update();
	},
	
	clear: function(loc) {
		this.locationValue = null;
		this.update();
	}
	
};

/** PidfLoEncoder **/
function PidfLoEncoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._typeNames = [];
	this._buttons = []
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	}
}
PidfLoEncoder.prototype = new TextEncoder();
PidfLoEncoder.prototype.encode = function() {
    var pidf = "";

    // Take inventory of what we have
    var gotLocation, gotGeo, gotAlt, gotAltErr, gotCivic, altUnit;
    gotLocation = (this.locationValue != null);
    if (gotLocation) {
        gotGeo = ((this.locationValue.geo != null) && (this.locationValue.geo.shape != null));
        gotCivic = (this.locationValue.civic != null);

        if (gotGeo) {
            gotAlt = ((this.locationValue.geo.altitudeInfo != null)&&
                      (this.locationValue.geo.altitudeInfo.altitude > 0));
            if (gotAlt) {
                gotAltErr = (this.locationValue.geo.altitudeInfo.hasError &&
                        (this.locationValue.geo.altitudeInfo.altitudeError > 0));
                altUnit = this.locationValue.geo.altitudeInfo.unit;
            }
        }
    }


    // If we don't have a usable location, say so
    if (!gotLocation || (!gotGeo && !gotCivic)) {
        this.textValue = "(no location available)";
        return;
    }

    // Construct PIDF header
    pidf += "<presence xmlns=\"urn:ietf:params:xml:ns:pidf\" \n";
    pidf += "          xmlns:gp=\"urn:ietf:params:xml:ns:pidf:geopriv10\" \n";
    pidf += "          xmlns:cl=\"urn:ietf:params:xml:ns:pidf:geopriv10:civicAddr\" \n";
    pidf += "          xmlns:gml=\"http://www.opengis.net/gml\" \n";
    pidf += "          xmlns:gs=\"http://www.opengis.net/pidflo/1.0\" \n";
    pidf += "          entity=\"pres:anonymous\@anonymous.invalid\"> \n";
    pidf += "  <tuple id=\"4EtM9LDLwWXx6eW4yrer1MRCu5VEBrnDl4ECaspl\"> \n";
    pidf += "  <status> \n";
    pidf += "    <geopriv xmlns=\"urn:ietf:params:xml:ns:pidf:geopriv10\"> \n";
    pidf += "      <location-info> \n";

    // Check whether altitude is specified in floors or meters, if at all
    var altFloors = null;
    if (gotAlt && (altUnit == Altitude.Units.Floors)) {
        // Just remember the number of floors, don't worry about the error
        altFloors = this.locationValue.geo.altitudeInfo.altitude;
    }

    // Add geodetic information if we have it
    if (this.locationValue.geo && this.locationValue.geo.shape) {
        var shape = this.locationValue.geo.shape;
        
        // If we have geodetic altitude, do some prep work
        var alt, minalt, maxalt;
        if (gotAlt && (altUnit == Altitude.Units.Meters)) {
            alt = this.locationValue.geo.altitudeInfo.altitude;
            if (gotAltErr) {
                minalt = alt - (this.locationValue.geo.altitudeInfo.altitudeError / 2);
                maxalt = alt + (this.locationValue.geo.altitudeInfo.altitudeError / 2);
            } else {
                minalt = alt;
                maxalt = alt;
            }
        } 

        // Treat each shape in turn, with and without altitude
        if (shape instanceof Point) {
            // NB: AltError is ignored in this case, since it's nonsensical
            if (!gotAlt) {
                // 2D Point
                pidf += "<gml:Point srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
                pidf += "  <gml:pos>"+ shape.points[0].lat() 
                      + " "+ shape.points[0].lng() +"</gml:pos>\n";
                pidf += "</gml:Point>\n";  
            } else {
                // 3D Point
                pidf += "<gml:Point srsName=\"urn:ogc:def:crs:EPSG::4979\"\n";
                pidf += "  <gml:pos>"+ shape.points[0].lat() 
                      + " "+ shape.points[0].lng() 
                      + " "+ alt +"</gml:pos>\n";
                pidf += "</gml:Point>\n";  
            }
        } else if (shape instanceof Circle) {
            var radius = shape.points[0].distanceFrom(shape.points[1]);
            if (!gotAlt) {
                // Circle
                pidf += "<gs:Circle srsName=\"urn:ogc:def:crs:EPSG::4326\">\n";
                pidf += "  <gml:pos>"+ shape.points[0].lat() 
                      + " "+ shape.points[0].lng() +"</gml:pos>\n";
                pidf += "  <gs:radius uom=\"urn:ogc:def:uom:EPSG::9001\">"
                      + radius 
                      + "</gs:radius>\n";
                pidf += "</gs:Circle>\n";   
            } else {
                // Ellipsoid
                pidf += "<gs:Ellipsoid srsName=\"urn:ogc:def:crs:EPSG::4979\">\n";
                pidf += "  <gml:pos>"+ shape.points[0].lat() 
                      + " " + shape.points[0].lng() 
                      + " " + alt + "</gml:pos>\n";
                pidf += "   <gs:semiMajorAxis uom=\"urn:ogc:def:uom:EPSG::9001\">\n";
                pidf += "     "+ radius +"\n";
                pidf += "  </gs:semiMajorAxis>\n";
                pidf += "  <gs:semiMinorAxis uom=\"urn:ogc:def:uom:EPSG::9001\">\n";
                pidf += "     "+ radius +"\n";
                pidf += "  </gs:semiMinorAxis>\n";
                pidf += "  <gs:verticalAxis uom=\"urn:ogc:def:uom:EPSG::9001\">\n";
                pidf += "     "+ ((maxalt-minalt)/2)+"\n";
                pidf += "  </gs:verticalAxis>\n";
                pidf += "  <gs:orientation uom=\"urn:ogc:def:uom:EPSG::9102\">\n";
                pidf += "     0\n";
                pidf += "  </gs:orientation>\n";
                pidf += "</gs:Ellipsoid>\n";
            }
        } else if (shape instanceof Rectangle) {
            // Compute points as a polygon
            var minlat = Math.min(shape.points[0].lat(), shape.points[1].lat());
            var maxlat = Math.max(shape.points[0].lat(), shape.points[1].lat());
            var minlng = Math.min(shape.points[0].lng(), shape.points[1].lng());
            var maxlng = Math.max(shape.points[0].lng(), shape.points[1].lng());     

            if (!gotAlt) {
                // Polygon    
                pidf += "<gml:Polygon srsName=\"urn:ogc:def:crs:EPSG::4326\">\n";
                pidf += "  <gml:exterior>\n";
                pidf += "    <gml:LinearRing>\n";
                pidf += "      <gml:pos>"+ minlat +" "+ minlng +"</gml:pos>\n";
                pidf += "      <gml:pos>"+ maxlat +" "+ minlng +"</gml:pos>\n";
                pidf += "      <gml:pos>"+ maxlat +" "+ maxlng +"</gml:pos>\n";
                pidf += "      <gml:pos>"+ minlat +" "+ maxlng +"</gml:pos>\n";
                pidf += "      <gml:pos>"+ minlat +" "+ minlng +"</gml:pos>\n";
                pidf += "    </gml:LinearRing>\n";
                pidf += "  </gml:exterior>\n";
                pidf += "</gml:Polygon>\n";   
            } else {
                // Prism
                pidf += "<gs:Prism srsName=\"urn:ogc:def:crs:EPSG::4979\">\n";
                pidf += "  <gs:base>\n";
                pidf += "    <gml:Polygon srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
                pidf += "        xmlns:gml=\"http://www.opengis.net/gml\" >\n";
                pidf += "      <gml:exterior>\n";
                pidf += "        <gml:LinearRing>\n";
                pidf += "          <gml:pos>"+ minlat +" "+ minlng +" "+ minalt +"</gml:pos>\n";
                pidf += "          <gml:pos>"+ maxlat +" "+ minlng +" "+ minalt +"</gml:pos>\n";
                pidf += "          <gml:pos>"+ maxlat +" "+ maxlng +" "+ minalt +"</gml:pos>\n";
                pidf += "          <gml:pos>"+ minlat +" "+ maxlng +" "+ minalt +"</gml:pos>\n";
                pidf += "          <gml:pos>"+ minlat +" "+ minlng +" "+ minalt +"</gml:pos>\n";
                pidf += "        </gml:LinearRing>\n";
                pidf += "      </gml:exterior>\n";
                pidf += "    </gml:Polygon>\n";   
                pidf += "  </gs:base>\n";
                pidf += "  <gs:height uom=\"urn:ogc:def:uom:EPSG::9001\">";
                pidf +=    (maxalt-minalt);
                pidf += "  </gs:height>\n";
                pidf += "</gs:Prism>\n";
            }
        } else if (shape instanceof Polygon) {
            // NB: Should be the same code as Rectangle above,
            //     except with a for-loop to iterate over the points
            if (!gotAlt) {
                // Polygon    
                pidf += "<gml:Polygon srsName=\"urn:ogc:def:crs:EPSG::4326\">\n";
                pidf += "  <gml:exterior>\n";
                pidf += "    <gml:LinearRing>\n";
                for (var i=0; i < shape.points.length; ++i) {
                pidf += "      <gml:pos>"+ shape.points[i].lat()
                      + " "+ shape.points[i].lng() 
                      + " "+ minalt+"</gml:pos>\n";
                }
                pidf += "    </gml:LinearRing>\n";
                pidf += "  </gml:exterior>\n";
                pidf += "</gml:Polygon>\n";   
            } else {
                // Prism
                pidf += "<gs:Prism srsName=\"urn:ogc:def:crs:EPSG::4979\">\n";
                pidf += "  <gs:base>\n";
                pidf += "    <gml:Polygon srsName=\"urn:ogc:def:crs:EPSG::4326\"\n";
                pidf += "        xmlns:gml=\"http://www.opengis.net/gml\" >\n";
                pidf += "      <gml:exterior>\n";
                pidf += "        <gml:LinearRing>\n";
                for (var i=0; i < shape.points.length; ++i) {
                pidf += "          <gml:pos>"+ shape.points[i].lat()
                      + " "+ shape.points[i].lng() 
                      + " "+ minalt+"</gml:pos>\n";
                }
                pidf += "        </gml:LinearRing>\n";
                pidf += "      </gml:exterior>\n";
                pidf += "    </gml:Polygon>\n";   
                pidf += "  </gs:base>\n";
                pidf += "  <gs:height uom=\"urn:ogc:def:uom:EPSG::9001\">";
                pidf +=    (maxalt-minalt);
                pidf += "  </gs:height>\n";
                pidf += "</gs:Prism>\n";
            }
        }
    }

    // Add civic information if we have it 
    if (this.locationValue.civic) {
        pidf += "        <cl:civicAddress>\n";
        var elements = this.locationValue.civic.getElements();
        for (name in elements) {
            if (name == "what") continue;
            pidf += "          <cl:"+ name +">"+ elements[name] +"</cl:" +name+">\n";
        }

        if (altFloors) {
            // NB: Ignores altError in this case, since it's not clear how to express it
            pidf += "          <cl:FLR>"+ altFloors + "</cl:FLR>\n";
        }

        pidf += "        </cl:civicAddress>\n";
    }

    // Add PIDF tail
    pidf += "      </location-info> \n";
    pidf += "      <usage-rules/> \n";
    pidf += "    </geopriv> \n";
    pidf += "  </status> \n";
    pidf += "  </tuple> \n";
    pidf += "</presence> \n";

    // Make the object HTML-safe
    pidf = pidf.replace(/&/g, '&amp;')
               .replace(/</g, '&lt;')
               .replace(/>/g, '&gt;')
               .replace(/"/g, '&quot;');

    this.textValue = pidf;    
};

/** W3CEncoder **/
function W3CEncoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._typeNames = [];
	this._buttons = []
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	}
}
W3CEncoder.prototype = new TextEncoder();
W3CEncoder.prototype.encode = function() {
    var obj = "";

    // Take inventory of what we have
    var gotLocation, gotGeo, gotAlt, gotAltErr, gotCivic, altUnit;
    gotLocation = (this.locationValue != null);
    if (gotLocation) {
        gotGeo = ((this.locationValue.geo != null) && (this.locationValue.geo.shape != null));
        gotCivic = (this.locationValue.civic != null);

        if (gotGeo) {
            gotAlt = ((this.locationValue.geo.altitudeInfo != null)&&
                      (this.locationValue.geo.altitudeInfo.altitude > 0));
            if (gotAlt) {
                gotAltErr = (this.locationValue.geo.altitudeInfo.hasError &&
                        (this.locationValue.geo.altitudeInfo.altitudeError > 0));
                altUnit = this.locationValue.geo.altitudeInfo.unit;
            }
        }
    }


    // If we don't have a usable location, say so
    if (!gotLocation || !gotGeo) {
        this.textValue = "(no location available)";
        return;
    }

    var shape = this.locationValue.geo.shape;
    var alt = this.locationValue.geo.altitudeInfo;
    obj += "{\n";
    obj += "  'coords' : {\n";
    obj += "    'latitude' : '"+ shape.getCentroid().lat() +"',\n";
    obj += "    'longitude' : '"+ shape.getCentroid().lng() +"',\n";
    obj += "    'accuracy' : '"+ shape.getUncertainty() +"',\n";
    if (gotAlt) {
        obj += "    'altitude' : '"+ alt.altitude +"',\n";
        if (gotAltErr && (alt.unit == Altitude.Units.Meters)) {
            obj += "    'altitudeAccuracy' : '"+ alt.altitudeError +"',\n";
        }
    }
    obj += "  },\n";
    obj += "  'timestamp' : '"+ (new Date()).getTime() +"'\n";
    obj += "}\n"; 

    this.textValue = obj;
};

/** DhcpEncoder **/
function DhcpEncoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._typeNames = ["Raw","Cisco","dhcpd"];
	this._buttons = [];
    this.optionValue = null;
    this.optionNumber = 0;
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	}
}
DhcpEncoder.prototype = new TextEncoder();
DhcpEncoder.prototype.optionValue = null;
DhcpEncoder.prototype.encode = function() {
	this.encodeOptionValue();
    
    if (this.optionValue == null) {
        this.textValue = "(no suitable location available)";
        return;
    }
     
    // Wrap the option according to the server type selected
    switch (this.typeName) {
        case "Raw":
            this.textValue = this.optionValue;
            break;
        case "Cisco":
            this.textValue = "option "+ this.optionNumber + " hex " + this.optionValue;
            break;
        case "dhcpd":
            this.textValue = "option loc-geo-"+ this.optionNumber + " code " + this.optionNumber + " = string;\n";
            this.textValue += "option loc-geo-"+ this.optionNumber + " " + this.optionValue;
            break;
    } 
};

/** Dhcp0Encoder **/
function Dhcp0Encoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._buttons = []
    this.optionNumber = 123;
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	} 
}
Dhcp0Encoder.LatLngIntLen = 9;
Dhcp0Encoder.LatLngFraLen = 25;
Dhcp0Encoder.AltIntLen = 22;
Dhcp0Encoder.AltFraLen = 8;
Dhcp0Encoder.bitMatchLen = function(val1, val2, intBits, fracBits) {
    var len;
    var totalLen = intBits + fracBits;
    var fp1 = Math.floor(val1 * Math.pow(2, fracBits));
    var fp2 = Math.floor(val2 * Math.pow(2, fracBits));
    for (len=1; k<intBits+fracBits; ++len) {
        var bit1 = (fp1 >> (totalLen - len)) % 2;
        var bit2 = (fp2 >> (totalLen - len)) % 2;
        if (bit1 != bit2) { break; }
    }
    return len-1;
};
Dhcp0Encoder.prototype = new DhcpEncoder();
Dhcp0Encoder.prototype.encodeOptionValue = function() {

    // Take inventory of what we have
    var gotLocation, gotGeo, gotAlt, gotAltErr, gotCivic, altUnit;
    gotLocation = (this.locationValue != null);
    if (gotLocation) {
        gotGeo = ((this.locationValue.geo != null) && (this.locationValue.geo.shape != null));
        gotCivic = (this.locationValue.civic != null);

        if (gotGeo) {
            gotAlt = ((this.locationValue.geo.altitudeInfo != null)&&
                      (this.locationValue.geo.altitudeInfo.altitude > 0));
            if (gotAlt) {
                gotAltErr = (this.locationValue.geo.altitudeInfo.hasError &&
                        (this.locationValue.geo.altitudeInfo.altitudeError > 0));
                altUnit = this.locationValue.geo.altitudeInfo.unit;
            }
        }
    }

    // If we don't have a usable location, say so
    if (!gotLocation || !gotGeo) {
        this.optionValue = null;
        return;
    }

    // Compute resolution inputs
    var shape = this.locationValue.geo.shape;
    var alt = this.locationValue.geo.altitudeInfo;
    var laRes = null; 
    var loRes = null; 
    var alRes = null; 
    
    if (shape instanceof Point) {
        laRes = 0;
        loRes = 0;
    } else {
        laRes = Dhcp0Encoder.bitMatchLength(
                  shape.getCentroid().lat() - shape.getLatUncertainty(), 
                  shape.getCentroid().lat() + shape.getLatUncertainty(),
                  Dhcp0Encoder.LatLngIntLen,
                  Dhcp0Encoder.LatLngFraLen);
        loRes = Dhcp0Encoder.bitMatchLength(
                  shape.getCentroid().lng() - shape.getLngUncertainty(), 
                  shape.getCentroid().lng() + shape.getLngUncertainty(),
                  Dhcp0Encoder.LatLngIntLen,
                  Dhcp0Encoder.LatLngFraLen);
    }

    if (gotAlt && gotAltErr && (alt.unit == Altitude.Units.Meters)) {
        alRes = Dhcp0Encoder.bitMatchLengh(
                  alt.altitude - alt.altitudeError,
                  alt.altitude + alt.altitudeError,
                  Dhcp0Encoder.AltIntLen,
                  Dhcp0Encoder.AltFraLen);
    } else {
        alRes = 0;
    }

    // Compute the option value
    var opt123 = new DhcpOption123();
    opt123.latitude = shape.getCentroid().lat();
    opt123.longitude = shape.getCentroid().lng();
    opt123.latitudeUncertainty = laRes;
    opt123.longitudeUncertainty = loRes;
    if (gotAlt) {
        opt123.altitude = alt.altitude;
        opt123.altitudeType = alt.unit;
    } else {
        opt123.altitude = 0;
        opt123.altitudeType = 0;
    }
    opt123.altitudeUncertainty = alRes;
    opt123.datum = (0x00 << 6) | 0x01; // Version = 0, datum=WGS84
    this.optionValue = opt123.encode().toString();
};


/** Dhcp1Encoder **/
function Dhcp1Encoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._buttons = [];
    this.optionNumber = 123;
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	}
}
Dhcp1Encoder.prototype = new DhcpEncoder();
Dhcp1Encoder.prototype.encodeOptionValue = function() {

    // Take inventory of what we have
    var gotLocation, gotGeo, gotAlt, gotAltErr, gotCivic, altUnit;
    gotLocation = (this.locationValue != null);
    if (gotLocation) {
        gotGeo = ((this.locationValue.geo != null) && (this.locationValue.geo.shape != null));
        gotCivic = (this.locationValue.civic != null);

        if (gotGeo) {
            gotAlt = ((this.locationValue.geo.altitudeInfo != null)&&
                      (this.locationValue.geo.altitudeInfo.altitude > 0));
            if (gotAlt) {
                gotAltErr = (this.locationValue.geo.altitudeInfo.hasError &&
                        (this.locationValue.geo.altitudeInfo.altitudeError > 0));
                altUnit = this.locationValue.geo.altitudeInfo.unit;
            }
        }
    }

    // If we don't have a usable location, say so
    if (!gotLocation || !gotGeo) {
        this.optionValue = null;
        return;
    }

    // Compute resolution inputs
    var shape = this.locationValue.geo.shape;
    var alt = this.locationValue.geo.altitudeInfo;
    var laRes = null; 
    var loRes = null; 
    var alRes = null; 
    
    if (shape instanceof Point) {
        laRes = 0;
        loRes = 0;
    } else {
        var latUnc = shape.getLatUncertainty();
        var lngUnc = shape.getLngUncertainty();
        laRes = Math.floor(8 - Math.log(latUnc)/Math.LN2); 
        loRes = Math.floor(8 - Math.log(lngUnc)/Math.LN2); 
    }

    if (gotAlt && gotAltErr && (alt.unit == Altitude.Units.Meters)) {
        alRes = Math.floor(21 - Math.Log(alt.altitudeError)/Math.LN2); 
    } else {
        alRes = 0;
    }

    // Compute the option value
    var opt123 = new DhcpOption123();
    opt123.latitude = shape.getCentroid().lat();
    opt123.longitude = shape.getCentroid().lng();
    opt123.latitudeUncertainty = laRes;
    opt123.longitudeUncertainty = loRes;
    if (gotAlt) {
        opt123.altitude = alt.altitude;
        opt123.altitudeType = alt.unit;
    } else {
        opt123.altitude = 0;
        opt123.altitudeType = 0;
    }
    opt123.altitudeUncertainty = alRes;
    opt123.datum = (0x01 << 6) | 0x01; // Version = 1, datum=WGS84
    this.optionValue = opt123.encode().toString();
};

/** DhcpCivicEncoder **/
function DhcpCivicEncoder(name, source) {
	this._controlElement = document.getElementById(name);
	this._source = source;
	this._buttons = [];
    this.optionNumber = 99;
	
	// No-argument constructor doesn't initialize (for inheritance purposes)
	if (name || source) {
		this.init();
	}
}
DhcpCivicEncoder.prototype = new DhcpEncoder();
DhcpCivicEncoder.prototype.encodeOptionValue = function() {
    // Take inventory of what we have
    var gotLocation=false, gotCivic=false;
    gotLocation = (this.locationValue != null);
    if (gotLocation) {
        gotCivic = (this.locationValue.civic != null);
    }

    // If we don't have a usable location, say so
    if (!gotLocation || !gotCivic) {
        this.optionValue = null;
        return;
    }

    // Encode the option value
    var civic = this.locationValue.civic;
    var elements = civic.getElements();
    var opt99 = new DhcpOption99();
    opt99.what = civic.what;
    opt99.country = elements["country"];
    for (type in elements) {
        opt99.pushCAtype(type, elements[type]);
    }
    this.optionValue = opt99.encode().toString();
};
