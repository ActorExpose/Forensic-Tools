function MapController(name) {
	// Grab a reference to the root element
	this._name = name;
	this._controlElement = document.getElementById(name);
	this.init();
}
MapController.States = {
	"START": 0,
	"DRAWING": 1,
	"DONE": 2
};
MapController.nextState = function(shape) {
	if (shape == null) {
		return MapController.States.START;
	}
	
	switch (shape.type) {
		case (Shape.Types.Point):
			if (shape.points.length >= 1) return MapController.States.DONE;
			else return MapController.States.DRAWING;
			break;
		case (Shape.Types.Circle):
            if ((shape.points.length >= 1)&&(shape.radius)) return MapController.States.DONE;
            else return MapController.States.DRAWING;
		case (Shape.Types.Rectangle):
			if (shape.points.length >= 5) return MapController.States.DONE;
			else return MapController.States.DRAWING;
			break;
		case (Shape.Types.Polygon):
			return MapController.States.DRAWING;
			break;
		default:
			return MapController.States.START;
	}
};
MapController.prototype = {
	// UI logic
	_name: null,
	_controlElement: null,
	_typeButtons: {},
	_endButton: null,
	_clearButton: null,
	_mapCanvas: null,
	_gmap: null,
	_overlay: null,

	_startLat: 0,
	_startLng: 0,
	_startZoom: 1,
	_defaultType: Shape.Types.Point,
	_activeClass: "active",
	
	init: function() {
		// Store this pointer for closures
		var mapController = this;
		
		// Add the type elements
		var name;
		for (typeName in Shape.Types) {
			var btn = document.createElement("button");
			btn.name = typeName;
			btn.controller = mapController;
			
			// Set appearance
			btn.innerHTML = typeName;
			btn.style.cssFloat = "left";
			btn.style.background = this._btnBackground;
			
			// Set action
			btn.onclick = mapController.onTypeButtonClick;
			
			// Add and store
			this._typeButtons[typeName] = btn;
			this._controlElement.appendChild(btn);
		}
		
		// Add the clear button
		{
			var btn = document.createElement("button");
			btn.name = "Clear";
			btn.controller = mapController;
			
			// Set appearance
			btn.innerHTML = "Clear";
			btn.style.cssFloat = "right";
			btn.style.padding = ".5ex";
			btn.style.border = "1px solid black";
			btn.style.background = this._btnBackground;
			
			// Set action
			btn.onclick = mapController.onClearButtonClick;
			
			// Add and store
			this._clearButton = btn;
			this._controlElement.appendChild(btn);
		}
		
		// Add the end button (hidden to start)
		{
			var btn = document.createElement("button");
			btn.name = "End";
			btn.controller = mapController;
			
			// Set appearance
			btn.innerHTML = "End";
			btn.style.cssFloat = "left";
			btn.style.padding = ".5ex";
			btn.style.border = "1px solid black";
			btn.style.background = this._btnBackground;
			btn.style.display = "none";
			
			// Set action
			btn.onclick = mapController.onEndButtonClick;
			
			// Add and store
			this._endButton = btn;
			this._controlElement.appendChild(btn);
		}
	
		// Add the map	
		{
			var map = document.createElement("div");
			
			map.style.background = "#666";
			map.style.clear = "both";
			map.style.height = "30em";
						
			this._mapCanvas = map;
			this._controlElement.appendChild(map);
		}

		if (GBrowserIsCompatible()) {
			// Add and wire up the GMap
			this._gmap = new GMap2(this._mapCanvas);
			this._gmap.setCenter( new GLatLng(this._startLat, this._startLng), this._startZoom );
			this._gmap.setUIToDefault();
			this._gmap.disableDoubleClickZoom();

			// Register click and double-click handlers
			GEvent.addListener(this._gmap, "click", function(overlay, latlng) {
				mapController.onMapClick(overlay, latlng);
			});
			
			GEvent.addListener(this._gmap, "dblclick", function(overlay, latlng) {
				mapController.onMapDblClick(overlay, latlng);
			});
		} else {
			this._mapCanvas.innerHTML = "Error: No google map available.";
		}
		
		this.shapeType = this._defaultType;
		this.updateTypeButtons();
	},
	
	update: function() {
		this.updateTypeButtons();
		this.updateEndButton();
		this.updateMap();
	},
	
	updateTypeButtons: function() {
		for (name in this._typeButtons) {
			// Set active / inactive
			if (this.shapeType == Shape.Types[name]) {
				this._typeButtons[name].setAttribute("class", this._activeClass);
			} else {
				this._typeButtons[name].setAttribute("class", "");
			}
			
			// Set enabled / disabled if DRAWING
			if ((this.state == MapController.States.DRAWING)&&
			    (this.shapeType != Shape.Types[name])) {
				this._typeButtons[name].disabled = "true";
			} else {
				this._typeButtons[name].disabled = null;
			}
		}
	},
	
	updateEndButton: function() {
		if ((this.state == MapController.States.DRAWING)&&
		    (this.shapeType == Shape.Types.Polygon)) {
			this._endButton.style.display = "";
		} else {
			this._endButton.style.display = "none";
		}
	},
	
	updateMap: function() {
		this.clearMap();
		if (this.shape) {
			this._overlay = this.shape.toGMapShape();
			this._gmap.addOverlay(this._overlay);
		}
	},
	
	clearMap: function() {
		if (this._overlay) {
			this._gmap.removeOverlay(this._overlay);
		}
	},
			
	
	// Application logic
	state: MapController.States.START,
	shapeType: Shape.Types.Point,
	shape: null,
	
	onTypeButtonClick: function(event) {
		event.target.controller.clear();
		event.target.controller.shapeType = Shape.Types[event.target.name];
		event.target.controller.update();
	},
	
	onClearButtonClick: function(event) {
		event.target.controller.clear();
		event.target.controller.update();
	},
	
	onMapClick: function(overlay, latlng) {
		if (this.state == MapController.States.START) {
			switch (this.shapeType) {
				case (Shape.Types.Point): 
					this.shape = new Point(); break;
				case (Shape.Types.Circle): 
					this.shape = new Circle(); break;
				case (Shape.Types.Rectangle): 
					this.shape = new Rectangle(); break;
				case (Shape.Types.Polygon): 
					this.shape = new Polygon(); break;
			}

			this.shape.addPoint(latlng);
		} else if (this.state == MapController.States.DRAWING) {
			this.shape.addPoint(latlng);
		} else if (this.state == MapController.States.DONE) {
			// Ignore the click if we have a shape already
			return;
		}
		
		this.state = MapController.nextState(this.shape);
		this.update();
		if (this.state == MapController.States.DONE) {
			this.notifyListeners(this.shape);
		}
	},
	
	onEndButtonClick: function(event) {
		var mapController = event.target.controller;
		
		if ((mapController.shapeType == Shape.Types.Polygon)&&
		    (mapController.state == MapController.States.DRAWING)) {
			mapController.shape.finish();
			mapController.state = MapController.States.DONE;
		} 
		
		mapController.update();
		mapController.notifyListeners(this.shape);
	},
	
	clear: function() {
		this.clearMap();
		this.clearListeners();
		this.state = MapController.States.START;
		this.shape = null;
	},
	
	

	// Listener management functions
	listeners: [],
	
	addListener: function(obj) {
		if (obj != null) {
			this.listeners.push(obj);
			return (this.listeners.length-1);
		}
	},
	
	removeListener: function(ix) {
		delete this.listeners[ix];
	},
	
	notifyListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].notify(this.shape); } 
	},
	
	clearListeners: function() {
		for (ix in this.listeners) { this.listeners[ix].clear(); } 
	}
};


