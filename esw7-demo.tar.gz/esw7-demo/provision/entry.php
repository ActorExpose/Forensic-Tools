<?

# Database config
$dbserver = ""; # DB_PARAM: Your information here
$username = ""; # DB_PARAM: Your information here
$password = ""; # DB_PARAM: Your information here
$database = ""; # DB_PARAM: Your information here

# Establish a database connection
$dbh = new mysqli($dbserver, $username, $password, $database);

# Prepare some statments
$addquery = $dbh->prepare("INSERT INTO `cache` (`prefix`, `len`, `geo`, `civic`) VALUES (?, ?, ?, ?)");
$delquery = $dbh->prepare("DELETE FROM `cache` WHERE `prefix`=? AND `len`=?");
$getquery = $dbh->prepare("SELECT * FROM `cache`");

# Check to see if we're in action
if ($_GET['action']) {
	$action = $_GET['action'];
	$params = $_GET;
} elseif ($_POST['action']) {
	$action = $_POST['action'];
	$params = $_POST;
} 

$status = "";
if ($action) {
	# Grab parameters
	$prefix = $dbh->real_escape_string($params['prefix']);
	$len = $dbh->real_escape_string($params['len']);
	$geo = $dbh->real_escape_string($params['geo']);
	$civic = $dbh->real_escape_string($params['civic']);

	# Add an entry if $action==insert
	if ($action == "insert") {
		$addquery->bind_param("siss", $prefix, $len, $geo, $civic);
		$addquery->execute();
		$message = "Adding: [$prefix] [$len] [$geo] [$civic]";
	}

	# Remove an entry if $action==delete
	if ($action == "delete") {
		$delquery->bind_param("si", $prefix, $len);
		$delquery->execute();
	}
}

?>

<html>

<head>
<title>IP geolocation provisioning</title>
<link rel="stylesheet" href="entry.css">
<link rel="stylesheet" href="./css/mapcontroller.css">
<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=API_KEY" type="text/javascript"></script>
<script src="./js/gmapshape.js" type="text/javascript"></script>
<script src="./js/geoecef.js" type="text/javascript"></script>
<script src="./js/shapes.js" type="text/javascript"></script>
<script src="./js/mapcontroller.js" type="text/javascript"></script>
<script src="./js/civic.js" type="text/javascript"></script>
<script src="./js/civiccontroller.js" type="text/javascript"></script>
<script>


var formManager = {
	// Management objects
	_geoController: null,
	_civicController: null,
	_geoListener: null,
	_civicListener: null,

	// State objects
	geo: null,
	civic: null,

	// UI references
	geoField: null,
	civicField: null,
	prefixIn: null,
	prefixOut: null,
	lenIn: null,
	lenOut: null,

	init: function(geoc, civicc) {
		var manager = this;
		var updateFn = function() { manager.update(); }

		{
			// Grab references to UI elements
			this.geoField = document.getElementById("geoField");
			this.civicField = document.getElementById("civicField");
			this.prefixIn = document.getElementById("prefixIn");
			this.prefixOut = document.getElementById("prefixOut");
			this.lenIn = document.getElementById("lenIn");
			this.lenOut = document.getElementById("lenOut");
			
			// Add update triggers
			this.prefixIn.onchange = updateFn;
			this.lenIn.onchange = updateFn;
		}

		{
			// Create and add geo listener
			this._geoController = geoc;
			this._geoListener = {
				notify: function(loc) {
					manager.geo = loc;
					manager.update();
				},
				clear: function() {
					manager.geo = null;
					manager.update();
				}
			};
			this._geoController.addListener(this._geoListener);
		}

		{
			// Create and add civic listener
			this._civicController = civicc;
			this._civicListener = {
				notify: function(loc) {
					manager.civic = null;
					manager.civic = loc;
					manager.update();
				},
				clear: function() {
					manager.civic = null;
					manager.update();
				}
			};
			this._civicController.addListener(this._civicListener);
		}

		this.update();
	},

	update: function() {
		// Update the geo and civic fields
		if (this.geo) {
			this.geoField.value = this.geo.toGeoShape()
		} else {
			this.geoField.value = "";
		}

		if (this.civic) {
			this.civicField.value = this.civic.toPidfLo();
		} else {
			this.civicField.value = "";
		}

		// Copy values from input to output fields
		this.prefixOut.value = this.prefixIn.value;
		this.lenOut.value = this.lenIn.value;
	},
}

var currTab = [
<?	
	$getquery->execute();
	$getquery->bind_result($prefix, $len, $geo, $civic);
	while ($getquery->fetch()) {
		echo "\t[\n";
		echo "\t\t\"". $prefix ."\",\n";
		echo "\t\t\"". $len ."\",\n";
		echo "\t\t\"". $geo ."\",\n";
		echo "\t\t\"". $civic ."\"\n";
		echo "\t],";
	}
?>
	[ "STOP" ]
];
var geoCell;
var geoObj;

function tableSetup(name) {
	var tab = document.getElementById(name);
	
	for (ix in currTab) {
		if (currTab[ix][0] == "STOP") break;

		var id = currTab[ix][0] + "/" + currTab[ix][1];
		var geo = currTab[ix][2];
		var civ = currTab[ix][3];
		
		var gc = document.getElementById(id+"-geo");
		var cc = document.getElementById(id+"-civic");

		gc.style.width = "20em";
		gc.style.height = "10em";
		gc.style.padding = ".5ex";
		Shape.fromGML(geo).quickMap(id+"-geo");
		//gc.innerHTML = Shape.fromGML(geo).toString();
		geoCell = gc;
		geoObj = Shape.fromGML(geo);

		cc.style.width = "20em";
		cc.style.height = "10em";
		cc.style.overflow = "auto";
		cc.innerHTML = Civic.fromPidf(civ).toHtmlTable();
	}
}

var mc, cc;
function load() {
	tableSetup("locations");

	mc = new MapController("geoInput");
	cc = new CivicController("civicInput");
	formManager.init(mc, cc);
}

</script>
</head>

<body onload="load()">

<!--
<div><? echo $message ?></div>
-->

<div id="content">
	<div id="head">
		IP <b>geolocation</b> provisioning<br/>
	</div>

	<!--
	<? if ($action)  { ?><h1>Action: <? echo $action; ?></h1><? } ?>
	<? if ($query)  { ?><h1>Query performed: <? echo $query; ?></h1><? } ?>
	<? if ($status) { ?><h1>Status: <? echo $status; ?></h1><? } ?>
	-->

	<h1>Assign a prefix to a location:</h1>

	<table border="0">
		<tr>
			<td class="label">Prefix:</td>
			<td class="input">
				<input type="text" id="prefixIn" size="15"/> /
				<select id="lenIn">
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
					<option value="24">24</option>
					<option value="25">25</option>
					<option value="26">26</option>
					<option value="27">27</option>
					<option value="28">28</option>
					<option value="29">29</option>
					<option value="30">30</option>
					<option value="31">31</option>
					<option value="32">32</option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="label">Geodetic Location:</td>
			<td class="input"><div id="geoInput" class="inputArea"></div></td>
		</tr>
		<tr>
			<td class="label">Civic Location:</td>
			<td class="input"><div id="civicInput" class="inputArea"></div></td>
		</tr>
		<tr>
			<td class="label"></td>
			<td class="input">
				<form method="POST" action="./entry.php">
				<input type="hidden" name="action" value="insert"/>
				<input type="hidden" name="prefix" id="prefixOut"/>
				<input type="hidden" name="len" id="lenOut" />
				<textarea name="geo" id="geoField" class="inputField" ></textarea>
				<textarea name="civic" id="civicField" class="inputField" ></textarea>
				<br/>
				<input type="submit" id="submit" value="Add location" />
				</form>
			</td>
		</tr>
	</table>

	<h1>View or delete provisioned locations</h1>
	<table id="locations" cellspacing="0">
		<tr class="header">
			<th>Prefix</th>
			<th>Geodetic</th>
			<th>Civic</th>
			<th></th>
		</tr>
		
<?
	$getquery->execute();
	$getquery->bind_result($prefix, $len, $geo, $civic);
	while ($getquery->fetch()) {
		$id = $prefix."/".$len;
		print "\t\t<tr>\n";
		print "\t\t\t<td>". $id ."</td>\n";
		print "\t\t\t<td><div id=\"". $id ."-geo\"</td>\n";
		print "\t\t\t<td id=\"". $id ."-civic\"></td>\n";
		print "\t\t\t<td><a href=\"?action=delete&prefix=". $prefix ."&len=". $len ."\">DELETE</a></td>\n";
		print "\t\t</tr>\n";
	}
?>
	</table>

	<div id="discovery">
		<p>LIS discovery record for this LIS</p>
		<pre>IN NAPTR 100   10   "u"  "LIS:HELD" (                            ; service
          "!*.!LIS_URL!  ; regex
          .                                                      ; replacement
          )</pre>
	</div>

	<div id="foot">Prepared for <a href="http://www.apricot2010.net/">APRICOT 2010 / APNIC 29</a> </div>
</div>

</body>

<?

# Close the DB connection now that we're done
$dbh->close();

?>
