ECRIT Demonstration from Emergency Services Workshop 7
======================================================


OVERVIEW
--------

The code in this demonstration allows you to set up a system that shows how IP
endpoints can discover their local emergency services and place calls to a Public
Safety Answering Point (PSAP) using technologies developed by the IETF ECRIT and
GEOPRIV working groups.

This material was presented during a demo at the 7th Emergency Services Workshop 
(ESW7), held in College Park, MD, USA from 11-13 May 2010.  The accompanying 
slides can be found at this URI:
<http://www.emergency-services-coordination.info/esw7-slides/ecrit_demo_v3.pptx>

As you set up this demo, it will be helpful to be familiar with the relevant 
protocol standards, which are listed in the REFERENCES section of this document.

Please see doc/network_topology.pdf doc/call_flow.pdf for graphical depictions
of the network and call flow of the ESW7 demonstration.


GENERAL SETUP INSTRUCTIONS
--------------------------

General steps to recreate the ESW7 demonstration are as follows:

1) Install the Internet Geolocation Toolkit (igtk) client library
2) Install the Firefox ECRIT client.
3) Setup LIS servers and the provisioning page.
4) Provision approprate locations for the LIS servers.
5) Setup the LoST server.
6) Configure the local networks with approprate DHCP/DNS entries. 


CLIENT SOFTWARE
---------------

The client software comes in three parts:
1. The base Internet Geolocation Toolkit client library
2. A Firefox extension that allows Firefox components to see the library
3. A Firefox extension that uses location from igtk to discover emergency services
 
To install these:
1. Add the DLLs in /client/igtk/ to your system path
2. Install /client/firefox/igtk-interface.xpi  (In Firefox, File > Open...)
2. Install /client/firefox/ecritxul.xpi  (In Firefox, File > Open...)

For more information on the igtk, including the source code, see:
<http://igtk.sourceforge.net/>

NOTE: The client software in this demo is only compatible with operating systems 
based on Windows NT, i.e., Windows NT, XP, and later.  Libraries for other platforms
can be built from the igtk source linked above.



NETWORK ARCHITECTURE
--------------------

Since ESW7 was hosted at the University of Maryland, which has different police
services from the surrounding county (but uses the county fire department) the demo
network for the ESW has two LANs, one that represents the UMD campus network, and
one that represents a network out in the county.  

In the demo, these local networks were represented with Linksys WRT-54 gateways. 
These devices provided DHCP and DNS functionality to support LIS discovery (as well 
as NAT to support Internet access). Guidelines for configuring these (or similar) 
routers can be found in doc/router-config.txt.

The configuration parameters below depend on where you have installed the included
LIS scripts.  You should replace the LIS_PATH values below with the appropriate 
path for your installation of the scripts.
 
=== Network 1: UMD Network ===
DHCP network name:	net1.wild.local
LIS URI:		http://LIS_PATH/net1-lis.pl

Services:	
urn:service:sos	: Campus security (SIP, SIPS, Wave)
urn:service:sos.police : Campus police (SIP, SIPS)
urn:service:sos.fire : (Provided by county; XMPP / GTalk)

=== Network 2: Off-campus network ====
DHCP network name:	net2.wild.local
LIS URI:		http://LIS_PATH/net2-lis.pl

Services:
urn:service:sos	: PG County PSAP (SIP, SIPS, XMPP/GTalk)
urn:service:sos.police : PG County police (SIP, SIPS)
urn:service:sos.fire : (Provided by county; XMPP / GTalk)

Connectivity architecture from ESW7 Demo:
[client]---[router-net1]---[WiMAX uplink]---[Internet]
[client]---[router-net2]---[WiMAX uplink]---[Internet]



LOCATION INFORMATION SERVERS (LIS)
----------------------------------

In this demo, the networks provide Location Information Servers implemented as
Perl CGI scripts.  LIS resources are contained in the following directories:

1. /lis/ : Simple location information servers that can be provisioned with prefix
           locations
2. /provision/ : A web page that can be used to provision location into the LISes

LIS services are provided by lis/net1-lis.pl and lis/net2-lis.pl. These represent
the servers for network 1 and network 2, respectively. Both servers are backed
by a database. The general directions for setting up these LIS instances are as
follows:


1. Set up the LIS
	-- Set up your database using lis/lis-db.sql
	-- Install perl dependencies for lis/net1-lis.pl and lis/net2-lis.pl 
           (look at "use" lines)
	-- Put your database parameters into net1-lis.pl and net2-lis.pl 
           (look for "DB_PARAM" lines)
	-- Put net1-lis.pl and net2-lis.pl in a place where they can run as CGI scripts
2. Set up the provisioning page
	-- Put your database parameters into provision/entry.php (look for "DB_PARAM")
	-- Put your Google Maps API key into provision/entry.php (look for "API_KEY")

The two LISes draw static location values from the provisioning database. Note
that this is a hardcode; specifically net1-lis.pl looks for the location provisioned with
the 10.0.0.1/32 prefix, and net2-lis.pl looks for the location provisioned with the 
10.0.0.2/32 prefix.

Accordingly, once the provisioning page is set up, provision two appropriate locations,
one with the 10.0.0.1/32 prefix and one with the 10.0.0.2/32 prefix. See
doc/provisioned_locations_example.pdf for the example configuration used at ESW7.



LOST SERVER
-----------

Example LoST server code can be found in lost/lost.php. This code serves LoST responses,
backed by a mysql database. Example lost data for this database is contained in 
php_lost.sql. The example data includes both service boundaries and PSAP contact 
information. Note that lost.php should be modified to use your database parameters
and information (look for "DB_PARAM").

The DB stores service boundaries as polygons in "Well-Known Text" (WKT) format.
<http://en.wikipedia.org/wiki/Well-known_text>

There are currently three polygons provisioned in the default LoST server in the EcritXUL
extension:
1. University of Maryland
2. PG County
3. PG County, less UMD

Two test points you can use:
Test point 1: Kim building = 38.99105 -76.937594 
Test point 2: Hanami Restaurant = 38.990847 -76.932836 



CLIENT AND PSAP ACCOUNTS
------------------------

Client and PSAP accounts at ESW7 were represented by gmail accounts. Calls were
then placed/received with Google Talk, using the Google Talk desktop software. Note 
that calling using other methods (SIP, Skype, etc.) can also be done, provided 
suitable accounts, PSAP URIs, and calling software are provisioned.


EXAMPLE CLIENT ACCOUNTS
Addresses		
client.in.distress@gmail.com	


EXAMPLE PSAP ACCOUNTS

Addresses					
psap.umd@gmail.com
psap.police@gmail.com					
psap.fire@gmail.com					
psap.mountain@gmail.com					
2233403155@sip2sip.info					

Display Name		URI							
UMD Security		sip:2233403709@sip2sip.info				
UMD Security		wave:googlewave.com!w%252BL3aWWpEiD			
UMD Police		sip:2233403711@sip2sip.info				
UMD Police		gtalk:call?jid=psap.umd@gmail.com			
PG County PSAP		sip:2233403713@sip2sip.info				
PG County PSAP		xmpp:psap.umd@gmail.com					
PG County PD		sip:2233403715@sip2sip.info				
PG County PD		xmpp:psap.police@gmail.com				
PG County PD		gtalk:call?jid=psap.police@gmail.com			
PG County FD		sip:2233403717@sip2sip.info				
PG County FD		xmpp:psap.fire@gmail.com				
PG County FD		gtalk:call?jid=psap.fire@gmail.com			

Note that the example PSAP information is contained in php_lost.sql



REFERENCES
----------

7th Emergency Services Workshop:
<http://www.emergency-services-coordination.info/esw7.html>

Framework for Emergency Calling using Internet Multimedia:
<http://tools.ietf.org/html/draft-ietf-ecrit-framework>

Location Information Server (LIS) Discovery:
<http://tools.ietf.org/html/draft-ietf-geopriv-lis-discovery>

HTTP Enabled Location Delivery (HELD):
<http://tools.ietf.org/html/draft-ietf-geopriv-http-location-delivery>

LoST - A Location-to-Service Translation Protocol:
<http://tools.ietf.org/html/rfc5222>





