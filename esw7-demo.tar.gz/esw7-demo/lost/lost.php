<?

# Database config
$dbserver = ""; # DB_PARAM: Your information here
$username = ""; # DB_PARAM: Your information here
$password = ""; # DB_PARAM: Your information here
$database = ""; # DB_PARAM: Your information here

function debug_log($msg) {
	#echo "<!-- [". $msg ."] -->\n";
}

function get_services($dbh) {
	$getquery = $dbh->prepare("SELECT DISTINCT `service` FROM `services`");
	$getquery->execute();
	$getquery->bind_result($urn);
	$urns = array();
	while ($getquery->fetch()) {
		array_push($urns, $urn);
	}
	$getquery->close();
	debug_log("Found ". count($urns) ." services");
	return $urns;
}

function get_uris($id, $dbh) {
	debug_log("SELECT `uri` FROM `contacts` WHERE (`service_id` LIKE '$id')");
 	$getquery = $dbh->prepare("SELECT `uri` FROM `contacts` WHERE (`service_id` LIKE ?)");
 	$getquery->bind_param("s", $id);
 	$uris = array();
 	$getquery->execute();
 	$getquery->bind_result($uri);
 	while ($getquery->fetch()) {
 		array_push( $uris, $uri );
 		debug_log($uri);
 	}
 	$getquery->close();
	return $uris;
}

function get_mappings($pt, $urn, $dbh) {
	# Get SB
	$sbs = get_service_boundary_ids($pt, $dbh);
	debug_log("Found ". count($sbs) ." service boundaries.");

	# For each SB, get services with that SB and the right URN
	$mappings = array();
	foreach ($sbs as $sb) {
		$getquery = $dbh->prepare("SELECT `id`, `serviceNumber`, `displayName` FROM `services` WHERE (`service` LIKE ?) AND (`serviceBoundary` LIKE ?)");
		$getquery->bind_param("ss", $urn, $sb);
		$getquery->execute();
		$getquery->bind_result($id, $serviceNumber, $displayName);
		while ($getquery->fetch()) {
			$mapping = array(
				'id' => $id,
				'service' => $urn,
				'serviceNumber' => $serviceNumber,
				'displayName' => $displayName
			);
			$mappings[] = $mapping;
		}
		$getquery->close();
	}
	debug_log("Found ". count($mappings) ." mappings");

	# NB: This needs to be separated because two queries can't be open at once
	for ($i=0; $i<count($mappings); ++$i) {
		$uris = get_uris($mappings[$i]['id'], $dbh);
		$mappings[$i]['uris'] = $uris;
		debug_log("URIs: ". join(", ", $mappings[$i]['uris']) );
	}

	return $mappings;
}


function pointInLinearRing($pt, $poly) {
	# Parse out the coordinates of the point, and the points of the polygon
	$parts = preg_split("/\s+/", $pt);
	$x = $parts[0];
	$y = $parts[1];
	$polypts = preg_split("/\s*,\s*/", $poly);

	# Count crossings
	$crossings = 0;
	$i = 1;
	$j = 0;
	for (; $i < count($polypts); $j = $i++) {
		$parts = preg_split("/\s+/", $polypts[$j]);
		$x1 = $parts[0]; $y1 = $parts[1];
		$parts = preg_split("/\s+/", $polypts[$i]);
		$x2 = $parts[0]; $y2 = $parts[1];

		if ( (($y1 > $y) != ($y2 > $y))
		    && ( $x < ($x1 - $x2)*($y-$y2)/($y1-$y2) + $x2 ) ) {
			++$crossings;
		}
	}

	# Point is inside if an odd number of crossings
	return ($crossings % 2 == 1);
}

function pointInPolygon($pt, $poly) {
	$poly = preg_replace("/^\s*\(/", "", $poly);
	$poly = preg_replace("/\)\s*$/", "", $poly);
	$rings = preg_split( "/\)\s*,\s*\(/", $poly );

	# Test for containment in the exterior ring
	while (!$rings[0]) { array_shift($rings); }
	if (!pointInLinearRing($pt, $rings[0])) { return FALSE; }
	array_shift($rings);

	# Test for containment in the interior rings
	foreach ($rings as $ring) {
		if (pointInLinearRing($pt, $ring)) {
			return FALSE;
		}
	}

	return TRUE;
}

function get_service_boundary_ids($pt, $dbh) {
	$getquery = $dbh->prepare("SELECT `id`, `sb` FROM serviceBoundaries");
	$getquery->execute();
	$getquery->bind_result($id,$sb);
	$ids = array();
	while ($getquery->fetch()) {
		if (pointInPolygon($pt, $sb)) {
			array_push($ids, $id);
			debug_log("Including SBID: ". $sb);
      		} else {
			debug_log("Excluding SBID: ". $id);
		}
	}
	return $ids;
}

function send_error_response($msg) {
	echo "<errors xmlns=\"urn:ietf:params:xml:ns:lost1\">";
	echo "  <internalError message=\"". $msg ."\" />";
	echo "</errors>";
	exit();
}

#BEGIN

# Check that we've got a POST request
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
	header("HTTP/1.1 405 Method not allowed; must be POST");
	exit();
}

# Should be application/lost+xml
header('Content-type: application/lost+xml');
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";

# Read the request body and parse
$request;
$requestType;
try {
	$requestString = $HTTP_RAW_POST_DATA;
	$request = new SimpleXMLElement($requestString);
	$requestType = $request->getName();
} catch (Exception $e) {
	send_error_response("Unable to parse request: ". $e->getMessage());
}

$dbh = new mysqli($dbserver, $username, $password, $database);

if ($requestType == 'listServices') {

	# Get list of services
	$urns = get_services($dbh);

	# Format response and return
	$responseType = $requestType ."Response";
	echo "<$responseType xmlns='urn:ietf:params:xml:ns:lost1'>\n";
	echo "  <serviceList>\n";
	foreach ($urns as $urn) {
		echo "    $urn\n";
	}
	echo "  </serviceList>\n";
	echo "</$responseType>";

} elseif ($requestType == 'findService') {

	# Set up namespaces for XPath
	$request->registerXPathNamespace("gs", "http://www.opengis.net/pidflo/1.0");
	$request->registerXPathNamespace("gml", "http://www.opengis.net/gml");
	$request->registerXPathNamespace("lost", "urn:ietf:params:xml:ns:lost1");

	# Look for a gml:pos element in the request (php XPath doesn't support relative paths with namepsaces)
	$pos1 = $request->xpath("/lost:findService/lost:location/gml:Point/gml:pos");
	$pos2 = $request->xpath("/lost:findService/lost:location/gs:Circle/gml:pos");
	if (!$pos1 && !$pos2) { send_error_response("No location provided"); }
	elseif ($pos1) { $pt = $pos1[0]; }
	elseif ($pos2) { $pt = $pos2[0]; }
	$pt = preg_replace("/^\s*/", "", $pt);
	$pt = preg_replace("/\s*$/", "", $pt);
	debug_log($pt);
	$pt = "38.99105 -76.937594";
	debug_log($pt);

	# Find the URN with XPath
	$services = $request->xpath("/lost:findService/lost:service");
	if (!$services) { send_error_response("No service listed"); }
	$urn = $services[0];

	$mappings = get_mappings($pt, $urn, $dbh);
	# TODO: Check to see if we have at least one usable mapping

	# Format responsee and return
	$responseType = $requestType ."Response";
	echo "<$responseType>\n";
	foreach ($mappings as $mapping) {
		echo "  <mapping>\n";
		echo "    <service>". $mapping['service'] ."</service>\n";
		echo "    <displayName>". $mapping['displayName'] ."</displayName>\n";
		echo "    <serviceNumber>". $mapping['serviceNumber'] ."</serviceNumber>\n";
 		if ($mapping['uris'] && (count($mapping['uris']) > 0)) {
			debug_log("printing URIs");
 			foreach ($mapping['uris'] as $uri) {
 			echo "    <uri>". $uri ."</uri>\n";
 			}
		} elseif (!$mapping['uris']) {
			debug_log("no URIs found");
		} elseif (count($mapping['uris']) == 0) {
			debug_log("URI list was empty");
		}
		echo "  </mapping>\n";
	}
	echo "</$responseType>";

}

$dbh->close();


?>
