-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Generation Time: Mar 02, 2010 at 05:52 PM
-- Server version: 5.0.88
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
  `prefix` text NOT NULL,
  `len` int(11) NOT NULL,
  `geo` text NOT NULL,
  `civic` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ref`
--

CREATE TABLE IF NOT EXISTS `ref` (
  `ip` text NOT NULL,
  `id` text NOT NULL,
  `civic` text NOT NULL,
  `geo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
